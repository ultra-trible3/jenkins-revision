from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_framework.routers import DefaultRouter
from apps.contracts.views import CompanyViewSet, CommitteeMemberViewSet, EntityViewSet, ContractAttachmentViewSet

company_router = DefaultRouter()
company_router.register("", CompanyViewSet, basename="company")

member_router = DefaultRouter()
member_router.register("", CommitteeMemberViewSet, basename="member")

entity_router = DefaultRouter()
entity_router.register("", EntityViewSet, basename="entity")

attachment_router = DefaultRouter()
attachment_router.register("", ContractAttachmentViewSet, basename="attachment")

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/auth/", include("apps.authentication.urls")),
    path("api/contracts/", include("apps.contracts.urls")),
    path("api/companies/", include(company_router.urls)),
    path("api/members/", include(member_router.urls)),
    path("api/entities/", include(entity_router.urls)),
    path("api/attachments/", include(attachment_router.urls)),
    path("api/dashboard/", include("apps.contracts.urls_dashboard")),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
