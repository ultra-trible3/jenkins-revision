import django_filters
from .models import Contract


class ContractFilter(django_filters.FilterSet):
    contract_number = django_filters.CharFilter(lookup_expr="icontains")
    template_name = django_filters.CharFilter(lookup_expr="exact")
    contract_type = django_filters.NumberFilter(field_name="contract_type_id", lookup_expr="exact")
    created_at_after = django_filters.DateFilter(
        field_name="created_at", lookup_expr="gte"
    )
    created_at_before = django_filters.DateFilter(
        field_name="created_at", lookup_expr="lte"
    )

    class Meta:
        model = Contract
        fields = ["contract_number", "template_name", "contract_type"]
