import os
import shutil
import subprocess
import sys
from datetime import datetime

from django.conf import settings
from django.http import FileResponse
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from .models import Contract, ContractType, ContractTypeTemplate, ContractDownload, Company, CommitteeMember, Entity, ContractAttachment
from .serializers import (
    ContractListSerializer,
    ContractDetailSerializer,
    ContractTypeSerializer,
    ContractDownloadSerializer,
    CompanySerializer,
    CommitteeMemberSerializer,
    EntitySerializer,
    ContractAttachmentSerializer,
)
from .filters import ContractFilter
from .services.word_generator import WordGenerator
from .services.pdf_generator import PDFGenerator
from .services.preview_renderer import PreviewRenderer


class ContractViewSet(viewsets.ModelViewSet):
    queryset = Contract.objects.all()
    permission_classes = [IsAuthenticated]
    filterset_class = ContractFilter
    search_fields = ["contract_number"]
    ordering_fields = ["contract_number", "created_at", "template_name"]
    ordering = ["-created_at"]

    def get_queryset(self):
        qs = Contract.objects.all()
        if self.action == "list":
            qs = qs.filter(parent_committee__isnull=True)
        return qs

    def get_serializer_class(self):
        if self.action == "list":
            return ContractListSerializer
        return ContractDetailSerializer

    def _save_to_storage(self, contract, template_key):
        now = datetime.now()
        type_name = contract.contract_type.name if contract.contract_type else "غير مصنف"
        dest_dir = os.path.join(
            settings.CONTRACT_STORAGE_PATH,
            "contracts",
            now.strftime("%Y"),
            type_name,
            now.strftime("%m-%d"),
            contract.contract_number,
        )
        os.makedirs(dest_dir, exist_ok=True)
        filename = f"{contract.contract_number}_{template_key}.docx"
        dest_path = os.path.join(dest_dir, filename)
        generator = WordGenerator(template_key=template_key)
        docx_path = generator.generate(contract)
        shutil.copy2(docx_path, dest_path)
        return dest_path

    def perform_create(self, serializer):
        contract_type_id = self.request.data.get("contract_type_id")
        if contract_type_id:
            contract = serializer.save(created_by=self.request.user, contract_type_id=contract_type_id)
        else:
            contract = serializer.save(created_by=self.request.user)

        for tpl in ["summary", "committee"]:
            try:
                self._save_to_storage(contract, tpl)
            except Exception:
                pass

    def perform_update(self, serializer):
        contract_type_id = self.request.data.get("contract_type_id")
        if contract_type_id is not None:
            serializer.save(contract_type_id=contract_type_id)
        else:
            serializer.save()

    @action(detail=False, methods=["get"])
    def templates(self, request):
        return Response(WordGenerator.list_templates())

    @action(detail=False, methods=["get"])
    def contract_types(self, request):
        types = ContractType.objects.all()
        serializer = ContractTypeSerializer(types, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=["post"])
    def duplicate(self, request, pk=None):
        import copy
        import uuid
        original = self.get_object()

        parent_committee_id = request.data.get("parent_committee_id")

        if parent_committee_id:
            parent = Contract.objects.get(pk=parent_committee_id)
            new_number = f"{parent.contract_number}-L-{uuid.uuid4().hex[:6].upper()}"
            new_contract = Contract(
                contract_number=new_number,
                template_name=original.template_name,
                contract_type=original.contract_type,
                form_data={},
                created_by=request.user,
                parent_committee=parent,
            )
            new_contract.save()
        else:
            form_data_copy = copy.deepcopy(original.form_data)
            new_number = f"{original.contract_number}-COPY-{uuid.uuid4().hex[:6].upper()}"
            original.pk = None
            original.contract_number = new_number
            original.created_by = request.user
            original.form_data = form_data_copy
            original.save()

        serializer = self.get_serializer(new_contract if parent_committee_id else original)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["get"])
    def children(self, request, pk=None):
        contract = self.get_object()
        children = contract.child_contracts.all()
        serializer = ContractListSerializer(children, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=["get"])
    def download_history(self, request):
        queryset = ContractDownload.objects.all()
        file_type = request.query_params.get("file_type")
        date_from = request.query_params.get("date_from")
        date_to = request.query_params.get("date_to")
        if file_type:
            queryset = queryset.filter(file_type=file_type)
        if date_from:
            queryset = queryset.filter(downloaded_at__gte=date_from)
        if date_to:
            queryset = queryset.filter(downloaded_at__lte=date_to)
        serializer = ContractDownloadSerializer(queryset, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=["get"])
    def word(self, request, pk=None):
        contract = self.get_object()
        template = request.query_params.get("template") or contract.template_name
        dest_path = self._save_to_storage(contract, template)
        response = FileResponse(
            open(dest_path, "rb"),
            as_attachment=True,
            filename=f"{contract.contract_number}_{template}.docx",
        )
        ContractDownload.objects.create(
            contract=contract,
            user=request.user if request.user.is_authenticated else None,
            file_type="word",
            contract_number=contract.contract_number,
        )

        return response

    @action(detail=True, methods=["get"])
    def open_storage_folder(self, request, pk=None):
        contract = self.get_object()
        created = contract.created_at
        type_name = contract.contract_type.name if contract.contract_type else "غير مصنف"
        folder = os.path.join(
            settings.CONTRACT_STORAGE_PATH,
            "contracts",
            created.strftime("%Y"),
            type_name,
            created.strftime("%m-%d"),
            contract.contract_number,
        )

        for tpl in ["summary", "committee"]:
            file_path = os.path.join(folder, f"{contract.contract_number}_{tpl}.docx")
            if not os.path.exists(file_path):
                try:
                    gen = WordGenerator(template_key=tpl)
                    docx_path = gen.generate(contract)
                    os.makedirs(folder, exist_ok=True)
                    shutil.copy2(docx_path, file_path)
                except Exception:
                    pass

        first_file = os.path.join(folder, f"{contract.contract_number}_{contract.template_name}.docx")

        if os.name == "nt":
            subprocess.Popen(["explorer", "/select,", first_file])
        elif sys.platform == "darwin":
            subprocess.Popen(["open", "-R", first_file])
        else:
            subprocess.Popen(["xdg-open", folder])

        return Response({"success": True})

    @action(detail=True, methods=["get", "post"])
    def preview(self, request, pk=None):
        contract = self.get_object()
        template = request.query_params.get("template") or contract.template_name
        edit_mode = request.query_params.get("mode") == "edit"
        override_data = request.data.get("form_data") if request.method == "POST" else None
        renderer = PreviewRenderer()
        html = renderer.render(contract, template_key=template, edit_mode=edit_mode, override_data=override_data)
        return Response({"html": html})

    @action(detail=True, methods=["get"])
    def pdf(self, request, pk=None):
        contract = self.get_object()
        template = request.query_params.get("template") or contract.template_name
        generator = PDFGenerator()
        pdf_path = generator.generate(contract, template_key=template)
        response = FileResponse(
            open(pdf_path, "rb"),
            as_attachment=True,
            filename=f"contract_{contract.contract_number}.pdf",
            content_type="application/pdf",
        )
        ContractDownload.objects.create(
            contract=contract,
            user=request.user if request.user.is_authenticated else None,
            file_type="pdf",
            contract_number=contract.contract_number,
        )
        return response


class CompanyViewSet(viewsets.ModelViewSet):
    queryset = Company.objects.all()
    serializer_class = CompanySerializer
    permission_classes = [IsAuthenticated]
    search_fields = ["name"]
    ordering_fields = ["name", "created_at"]
    ordering = ["name"]


class CommitteeMemberViewSet(viewsets.ModelViewSet):
    queryset = CommitteeMember.objects.all()
    serializer_class = CommitteeMemberSerializer
    permission_classes = [IsAuthenticated]
    search_fields = ["name"]
    ordering_fields = ["name", "role", "created_at"]
    ordering = ["role", "name"]


class EntityViewSet(viewsets.ModelViewSet):
    queryset = Entity.objects.all()
    serializer_class = EntitySerializer
    permission_classes = [IsAuthenticated]
    search_fields = ["name"]
    ordering_fields = ["name", "created_at"]
    ordering = ["name"]


class ContractAttachmentViewSet(viewsets.ModelViewSet):
    serializer_class = ContractAttachmentSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = ContractAttachment.objects.all()
        contract_id = self.request.query_params.get("contract_id")
        if contract_id:
            queryset = queryset.filter(contract_id=contract_id)
        return queryset

    def perform_create(self, serializer):
        import os
        uploaded_file = self.request.FILES.get("file")
        original_name = uploaded_file.name if uploaded_file else ""
        ext = os.path.splitext(original_name)[1].lower().replace(".", "")
        file_type = ext if ext in ("pdf", "doc", "docx") else "other"
        file_size = uploaded_file.size if uploaded_file else 0
        serializer.save(
            original_name=original_name,
            file_type=file_type,
            file_size=file_size,
        )
