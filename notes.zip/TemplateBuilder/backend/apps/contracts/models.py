from django.db import models
from django.conf import settings


TEMPLATE_CHOICES = [("summary", "Summary"), ("committee", "Committee")]  # ← add new templates here


class ContractType(models.Model):
    name = models.CharField(max_length=100, unique=True, verbose_name="Contract Type")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["name"]
        verbose_name = "Contract Type"
        verbose_name_plural = "Contract Types"

    def __str__(self):
        return self.name


class ContractTypeTemplate(models.Model):
    contract_type = models.ForeignKey(
        ContractType, on_delete=models.CASCADE, related_name="templates"
    )
    template_key = models.CharField(max_length=50)

    class Meta:
        unique_together = ("contract_type", "template_key")
        verbose_name = "Contract Type Template"
        verbose_name_plural = "Contract Type Templates"

    def __str__(self):
        return f"{self.contract_type.name} - {self.template_key}"


class Contract(models.Model):
    contract_number = models.CharField(
        max_length=100, unique=True, verbose_name="Contract Number"
    )
    template_name = models.CharField(
        max_length=50,
        verbose_name="Template",
        default="committee",
        choices=TEMPLATE_CHOICES,
    )
    contract_type = models.ForeignKey(
        ContractType,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="contracts",
        verbose_name="Contract Type",
    )
    form_data = models.JSONField(
        verbose_name="Form Data", default=dict, blank=True
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="created_contracts",
        verbose_name="Created By",
    )
    parent_committee = models.ForeignKey(
        'self',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='child_contracts',
        verbose_name='اللجنة الأصلية',
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Created At")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Updated At")

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "Contract"
        verbose_name_plural = "Contracts"

    def save(self, *args, **kwargs):
        if not self.contract_number:
            last = Contract.objects.order_by('-id').first()
            next_num = (last.id + 1) if last else 1
            self.contract_number = f"C-{next_num:04d}"
        super().save(*args, **kwargs)

    def __str__(self):
        ct = f" - {self.contract_type.name}" if self.contract_type else ""
        return f"Contract {self.contract_number} ({self.get_template_name_display()}{ct})"


class ContractDownload(models.Model):
    contract = models.ForeignKey(
        Contract, on_delete=models.CASCADE, related_name="downloads",
        verbose_name="Contract"
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, verbose_name="Downloaded By"
    )
    file_type = models.CharField(max_length=10, verbose_name="File Type")
    downloaded_at = models.DateTimeField(auto_now_add=True, verbose_name="Downloaded At")
    contract_number = models.CharField(max_length=100, verbose_name="Contract Number")

    class Meta:
        ordering = ["-downloaded_at"]
        verbose_name = "Contract Download"
        verbose_name_plural = "Contract Downloads"

    def __str__(self):
        return f"{self.contract_number} - {self.file_type} - {self.downloaded_at}"


def attachment_upload_path(instance, filename):
    if instance.contract:
        return f"attachments/{instance.contract.contract_number}/{filename}"
    return f"attachments/pending/{filename}"


class ContractAttachment(models.Model):
    contract = models.ForeignKey(
        Contract, on_delete=models.CASCADE, related_name="attachments",
        verbose_name="Contract", null=True, blank=True
    )
    file = models.FileField(upload_to=attachment_upload_path, verbose_name="File")
    original_name = models.CharField(max_length=255, verbose_name="Original Name")
    file_type = models.CharField(max_length=10, verbose_name="File Type")
    file_size = models.PositiveIntegerField(default=0, verbose_name="File Size (bytes)")
    uploaded_at = models.DateTimeField(auto_now_add=True, verbose_name="Uploaded At")

    class Meta:
        ordering = ["-uploaded_at"]
        verbose_name = "Contract Attachment"
        verbose_name_plural = "Contract Attachments"

    def __str__(self):
        return f"{self.original_name} ({self.contract.contract_number})"


class Company(models.Model):
    name = models.CharField(max_length=200, verbose_name="Company Name")
    is_active = models.BooleanField(default=True, verbose_name="Active")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Created At")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Updated At")

    class Meta:
        ordering = ["name"]
        verbose_name = "Company"
        verbose_name_plural = "Companies"

    def __str__(self):
        return self.name


class CommitteeMember(models.Model):
    ROLE_CHOICES = [
        ('chair', 'رئيس اللجنة'),
        ('financial', 'عضو مالي'),
        ('company', 'عضو الشركة'),
        ('technical', 'عضو فني'),
    ]
    name = models.CharField(max_length=200, verbose_name="Member Name")
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, verbose_name="Role")
    is_active = models.BooleanField(default=True, verbose_name="Active")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Created At")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Updated At")

    class Meta:
        ordering = ["role", "name"]
        verbose_name = "Committee Member"
        verbose_name_plural = "Committee Members"

    def __str__(self):
        return f"{self.get_role_display()} - {self.name}"


class Entity(models.Model):
    name = models.CharField(max_length=200, verbose_name="Entity Name")
    is_active = models.BooleanField(default=True, verbose_name="Active")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Created At")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Updated At")

    class Meta:
        ordering = ["name"]
        verbose_name = "Entity"
        verbose_name_plural = "Entities"

    def __str__(self):
        return self.name
