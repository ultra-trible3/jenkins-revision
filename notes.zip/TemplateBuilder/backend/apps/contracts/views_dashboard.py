from django.db.models import Count
from django.utils import timezone
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from .models import Contract


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def dashboard_stats(request):
    today = timezone.now().date()
    total_contracts = Contract.objects.count()
    contracts_today = Contract.objects.filter(
        created_at__date=today
    ).count()

    return Response(
        {
            "total_contracts": total_contracts,
            "contracts_today": contracts_today,
        }
    )


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def committee_stats(request):
    today = timezone.now().date()
    committees = Contract.objects.filter(template_name="committee")

    total = committees.count()
    today_count = committees.filter(created_at__date=today).count()

    recent = []
    for c in committees.order_by("-created_at")[:10]:
        fd = c.form_data or {}
        recent.append({
            "id": c.id,
            "contract_number": c.contract_number,
            "description": fd.get("input_description", ""),
            "date": fd.get("date", ""),
            "created_at": c.created_at.strftime("%Y-%m-%d %H:%M") if c.created_at else "",
        })

    return Response({
        "total_committees": total,
        "committees_today": today_count,
        "recent_committees": recent,
    })
