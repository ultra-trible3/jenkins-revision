import re
import tempfile
from datetime import datetime
from pathlib import Path
from copy import deepcopy
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

from .template_config import TEMPLATE_ROOT, TEMPLATES_CONFIG

_ARABIC_DIGITS = str.maketrans('0123456789', '٠١٢٣٤٥٦٧٨٩')
_ARABIC_TO_WESTERN = str.maketrans('٠١٢٣٤٥٦٧٨٩', '0123456789')
_LRE = '\u202a'
_PDF = '\u202c'


def _repair_corrupt_date(s):
    parts = s.replace('-', '/').split('/')
    if len(parts) == 3:
        fixed = []
        for i, p in enumerate(parts):
            if i > 0 and p.isdigit() and len(p) == 4 and p[:2] in ('19', '20'):
                fixed.append(p[2:])
            else:
                fixed.append(p)
        return '/'.join(fixed)
    return s


def _format_date(val):
    s = str(val).translate(_ARABIC_TO_WESTERN).replace('-', '/')
    s = s.split('T')[0].split('+')[0].split()[0]
    s = _repair_corrupt_date(s)
    for fmt in ('%d/%m/%Y', '%Y/%m/%d', '%m/%d/%Y', '%d/%m/%y'):
        try:
            return datetime.strptime(s, fmt).strftime('%Y/%m/%d')
        except ValueError:
            continue
    parts = s.split('/')
    if len(parts) == 3:
        a, b, c = [p.zfill(2) if len(p) < 2 else p for p in parts]
        if len(c) == 2:
            c = '20' + c
        if a.isdigit() and b.isdigit() and c.isdigit():
            if int(a) > 31:
                return f"{a}/{b}/{c}"
            if int(b) > 12:
                return f"{c}/{b}/{a}"
            return f"{c}/{b}/{a}"
    return s


_DATE_LTR_PATTERN = re.compile(r'(\d{4}/\d{2}/\d{2})')


def _fix_date_ltr_paragraph(p):
    if not p.runs:
        return
    full = p.text
    parts = _DATE_LTR_PATTERN.split(full)
    if len(parts) <= 1:
        return

    src_element = p.runs[0]._element
    parent = src_element.getparent()

    for r in list(p.runs):
        parent.remove(r._element)

    for part in parts:
        if not part:
            continue
        new_run = deepcopy(src_element)
        t = new_run.find(qn('w:t'))
        if t is not None:
            t.text = part
        if _DATE_LTR_PATTERN.fullmatch(part):
            rpr = new_run.find(qn('w:rPr'))
            if rpr is None:
                rpr = OxmlElement('w:rPr')
                new_run.insert(0, rpr)
            rtl = OxmlElement('w:rtl')
            rtl.set(qn('w:val'), '0')
            rpr.append(rtl)
        parent.append(new_run)


def _iter_text_elements(doc):
    """Yield all text-containing XML elements in the document."""
    for p in doc.paragraphs:
        for run in p.runs:
            yield run._element
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    for run in p.runs:
                        yield run._element
    for section in doc.sections:
        for p in section.header.paragraphs:
            for run in p.runs:
                yield run._element
        for p in section.footer.paragraphs:
            for run in p.runs:
                yield run._element



class WordGenerator:
    """
    Generates Word documents by replacing (variable_name) placeholders
    in .docx templates using python-docx. Supports multiple templates.
    """

    def __init__(self, template_key="committee"):
        self.template_key = template_key
        config = TEMPLATES_CONFIG.get(template_key, TEMPLATES_CONFIG["committee"])
        self.template_path = TEMPLATE_ROOT / config["file"]

    @classmethod
    def list_templates(cls):
        result = []
        for key, cfg in TEMPLATES_CONFIG.items():
            # Also load the template to list its variables
            tpl_path = TEMPLATE_ROOT / cfg["file"]
            variables = []
            if tpl_path.exists():
                doc = Document(str(tpl_path))
                full_text = "\n".join(
                    p.text for p in doc.paragraphs
                )
                for table in doc.tables:
                    for row in table.rows:
                        for cell in row.cells:
                            full_text += "\n" + cell.text
                for section in doc.sections:
                    for p in section.header.paragraphs:
                        full_text += "\n" + p.text
                    for p in section.footer.paragraphs:
                        full_text += "\n" + p.text
                found = sorted(
                    set(
                        v.strip()
                        for v in re.findall(r"\(([a-zA-Z0-9_ \[\]:]+)\)", full_text)
                        if v.strip()
                    )
                )
                variables = [
                    {"key": v, "label": v.replace("_", " ").title()}
                    for v in found
                ]
            result.append(
                {"id": key, "label": cfg["label"], "file": cfg["file"], "variables": variables}
            )
        return result

    def generate(self, contract):
        doc = self._render_doc(contract)
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".docx")
        doc.save(tmp.name)
        return tmp.name

    def render_content(self, contract):
        """Return rendered document content as structured data for preview."""
        doc = self._render_doc(contract)
        content = []

        for p in doc.paragraphs:
            text = p.text.strip()
            if text:
                content.append({
                    "type": "paragraph",
                    "text": text,
                    "alignment": str(p.alignment) if p.alignment else "LEFT",
                })

        for table in doc.tables:
            rows = []
            for row in table.rows:
                rows.append([cell.text.strip() for cell in row.cells])
            if any(any(c for c in r) for r in rows):
                content.append({"type": "table", "rows": rows})

        return content

    def _render_doc(self, contract):
        """Create a copy of the template with all placeholders replaced."""
        doc = Document(str(self.template_path))
        form_data = contract.form_data or {}

        KEY_ALIASES = {
            # new → old aliases (backward compat: new templates with old form_data)
            'category': 'drop_downlist',
            'currency': 'drop_down_list_currency',
            'full_budget': 'input2_budget',
            'input_year': 'input',
            'percentage_page1': 'input_percentage_page1',
            'final_budget': 'input3_budget',
            'input_description': 'description_input',
            'list_member[0]': 'drop_down_list_member[0]',
            'list_member[1]': 'drop_down_list_ member[1]',
            'list_member[2]': 'drop_down_list_ member[2]',
            'list_member[3]': 'drop_down_list_ member[3]',
            # old → new aliases (for old templates with new form_data)
            'drop_down_list_ member[0]': 'list_member[0]',
            'drop_down_list_ member[1]': 'list_member[1]',
            'drop_down_list_ member[2]': 'list_member[2]',
            'drop_down_list_ member[3]': 'list_member[3]',
            'drop_down_list_member[0]': 'list_member[0]',
            'drop_down_list_member[1]': 'list_member[1]',
            'drop_down_list_member[2]': 'list_member[2]',
            'drop_down_list_member[3]': 'list_member[3]',
            'drop_downlist': 'category',
            'drop_down_list_currency': 'currency',
            'input2_budget': 'full_budget',
            'input': 'input_year',
            'input_percentage_page1': 'percentage_page1',
            'input3_budget': 'final_budget',
            # typo / legacy aliases
            'comapny2': 'company2',
            'input_percentage[0:100]': 'input_percentage_page1',
        }

        DATE_KEYS = {'date', 'date2', 'day_input'}

        def resolve(key):
            if key.startswith('__'):
                return 'True'
            # If a company is selected as primary, use its value for company1
            if key == 'company1':
                selected = form_data.get('_selected_company')
                if selected and selected != 'company1':
                    sv = form_data.get(selected)
                    if sv and str(sv).strip():
                        return str(sv)
            exact = form_data.get(key)
            if exact and str(exact).strip():
                return str(exact)
            norm = re.sub(r'\s+', '', key)
            if norm != key:
                nv = form_data.get(norm)
                if nv and str(nv).strip():
                    return str(nv)
            mapped = KEY_ALIASES.get(key) or KEY_ALIASES.get(norm)
            if mapped:
                av = form_data.get(mapped)
                if av and str(av).strip():
                    return str(av)
            return exact  # fallback to exact (even if empty) or None

        def replace_val(match):
            key = match.group(1).strip()
            val = resolve(key)
            if val is not None:
                if key in DATE_KEYS:
                    formatted = _format_date(val)
                    val = _LRE + formatted + _PDF
                if key == 'input_hour':
                    val = str(val).replace(':', '')
                return str(val).translate(_ARABIC_DIGITS)
            return match.group(0)

        to_remove = []

        for p in doc.paragraphs:
            if self._apply_conditional_text(p, resolve):
                to_remove.append(p)
            self._replace_in_paragraph(p, replace_val)

        for p in to_remove:
            try:
                p._element.getparent().remove(p._element)
            except Exception:
                pass

        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    for p in cell.paragraphs:
                        self._apply_conditional_text(p, resolve)
                        self._replace_in_paragraph(p, replace_val)

            # Hide company columns with no data (Summary template)
            hidden = set()
            seen = set()
            col_pos = 0
            for cell in table.rows[0].cells:
                eid = id(cell._tc)
                if eid in seen:
                    continue
                seen.add(eid)
                tcPr = cell._tc.find(qn('w:tcPr'))
                gs = tcPr.find(qn('w:gridSpan')) if tcPr is not None else None
                span = int(gs.get(qn('w:val'))) if gs is not None else 1
                m = re.search(r'\(company(\d+)\)', cell.text)
                if m:
                    company_key = f'company{m.group(1)}'
                    if not resolve(company_key) or not str(resolve(company_key)).strip():
                        hidden.update(range(col_pos, col_pos + span))
                col_pos += span
            if hidden:
                # Remove hidden gridCols from tblGrid
                tblGrid = table._tbl.find(qn('w:tblGrid'))
                if tblGrid is not None:
                    gc_elements = list(tblGrid.findall(qn('w:gridCol')))
                    col_pos = 0
                    for gc in gc_elements:
                        pos = col_pos
                        col_pos += 1
                        if pos in hidden:
                            tblGrid.remove(gc)
                # Process each row: remove cells, adjust gridSpan
                for row in table.rows:
                    tc_elements = list(row._tr.findall(qn('w:tc')))
                    col_pos = 0
                    for tc in tc_elements:
                        tcPr = tc.find(qn('w:tcPr'))
                        gs = tcPr.find(qn('w:gridSpan')) if tcPr is not None else None
                        span = int(gs.get(qn('w:val'))) if gs is not None else 1
                        cell_cols = set(range(col_pos, col_pos + span))

                        if cell_cols.issubset(hidden):
                            row._tr.remove(tc)
                        else:
                            visible = len(cell_cols - hidden)
                            if gs is not None and visible != span:
                                if visible > 1:
                                    gs.set(qn('w:val'), str(visible))
                                else:
                                    tcPr.remove(gs)
                        col_pos += span
        for section in doc.sections:
            for p in section.header.paragraphs:
                self._apply_conditional_text(p, resolve)
                self._replace_in_paragraph(p, replace_val)
            for p in section.footer.paragraphs:
                self._apply_conditional_text(p, resolve)
                self._replace_in_paragraph(p, replace_val)

        for p in doc.paragraphs:
            _fix_date_ltr_paragraph(p)
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    for p in cell.paragraphs:
                        _fix_date_ltr_paragraph(p)
        for section in doc.sections:
            for p in section.header.paragraphs:
                _fix_date_ltr_paragraph(p)
            for p in section.footer.paragraphs:
                _fix_date_ltr_paragraph(p)

        return doc

    def _replace_in_paragraph(self, paragraph, replace_func):
        """Replace (var) patterns in a paragraph, handling multi-run text."""
        full_text = paragraph.text
        if "(" not in full_text:
            return

        new_text = re.sub(r"\(([a-zA-Z0-9_ \[\]:]+)\)", replace_func, full_text)
        if new_text == full_text:
            return

        for i, run in enumerate(paragraph.runs):
            if i == 0:
                run.text = new_text
            else:
                run.text = ""

        if not paragraph.runs:
            run = paragraph.add_run(new_text)

    def _process_conditionals(self, text, resolve_func):
        """Evaluate [if:key]...[end] blocks in text. Returns processed text."""
        if '[' not in text:
            return text
        processed = text
        while True:
            m = re.search(r'\[if:(\w+)\]', processed)
            if not m:
                break
            var_key = m.group(1)
            val = resolve_func(var_key)
            end_idx = processed.find('[end]', m.end())

            before = processed[:m.start()]
            after = processed[end_idx + 5:] if end_idx >= 0 else ''
            content = processed[m.end():end_idx] if end_idx >= 0 else processed[m.end():]

            if val and str(val).strip():
                processed = before + content + after
            else:
                processed = before + after

        return re.sub(r'\[end\]', '', processed)

    def _apply_conditional_text(self, p, resolve_func):
        """Apply [if:] / [end] processing to paragraph. Returns True if now empty."""
        text = p.text
        if '[' not in text:
            return False
        processed = self._process_conditionals(text, resolve_func)
        if processed == text:
            return False
        for i, run in enumerate(p.runs):
            run.text = processed if i == 0 else ""
        return not processed.strip()
