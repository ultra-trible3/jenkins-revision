from pathlib import Path

TEMPLATE_ROOT = (
    Path(__file__).resolve().parent.parent.parent.parent
    / "templates" / "word" / "contract" / "1"
)

TEMPLATES_CONFIG = {
    "summary": {
        "file": "Summary.docx",
        "label": "Summary",
        "landscape": True,
    },
    "committee": {
        "file": "Committee.docx",
        "label": "Committee",
    },
}
