import tempfile
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm, cm
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors


class PDFGenerator:
    def generate(self, contract, template_key=None):
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
        doc = SimpleDocTemplate(
            tmp.name,
            pagesize=A4,
            rightMargin=2 * cm,
            leftMargin=2 * cm,
            topMargin=2 * cm,
            bottomMargin=2 * cm,
        )

        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            "Title2", parent=styles["Title"], fontSize=18, alignment=TA_CENTER, spaceAfter=20
        )
        normal = ParagraphStyle(
            "Normal2", parent=styles["Normal"], fontSize=10, alignment=TA_LEFT, spaceAfter=6
        )
        bold_style = ParagraphStyle(
            "Bold", parent=normal, fontName="Helvetica-Bold"
        )

        story = []
        story.append(Paragraph(f"Contract: {contract.contract_number}", title_style))
        story.append(
            Paragraph(
                f"Template: {contract.get_template_name_display()}",
                ParagraphStyle("Sub", parent=normal, alignment=TA_CENTER, textColor=colors.grey),
            )
        )
        story.append(Spacer(1, 10 * mm))

        data = [["Field", "Value"]]
        for key, value in (contract.form_data or {}).items():
            data.append([key, str(value)])

        table = Table(data, colWidths=[6 * cm, 10 * cm])
        table.setStyle(
            TableStyle(
                [
                    ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
                    ("FONTSIZE", (0, 0), (-1, -1), 9),
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#166534")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                    ("TOPPADDING", (0, 0), (-1, -1), 5),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#E5E7EB")),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ]
            )
        )
        story.append(table)
        doc.build(story)
        return tmp.name
