import re
from datetime import datetime
from docx import Document
from docx.oxml.ns import qn

from .template_config import TEMPLATE_ROOT, TEMPLATES_CONFIG

def _repair_corrupt_date(s):
    parts = s.replace('-', '/').split('/')
    if len(parts) == 3:
        fixed = []
        for i, p in enumerate(parts):
            if i > 0 and p.isdigit() and len(p) == 4 and p[:2] in ('19', '20'):
                fixed.append(p[2:])
            else:
                fixed.append(p)
        return '/'.join(fixed)
    return s


def _format_date(val):
    s = str(val).translate(_ARABIC_TO_WESTERN).replace('-', '/')
    s = s.split('T')[0].split('+')[0].split()[0]
    s = _repair_corrupt_date(s)
    for fmt in ('%d/%m/%Y', '%Y/%m/%d', '%m/%d/%Y', '%d/%m/%y'):
        try:
            return datetime.strptime(s, fmt).strftime('%Y/%m/%d')
        except ValueError:
            continue
    parts = s.split('/')
    if len(parts) == 3:
        a, b, c = [p.zfill(2) if len(p) < 2 else p for p in parts]
        if len(c) == 2:
            c = '20' + c
        if a.isdigit() and b.isdigit() and c.isdigit():
            if int(a) > 31:
                return f"{a}/{b}/{c}"
            if int(b) > 12:
                return f"{c}/{b}/{a}"
            return f"{c}/{b}/{a}"
    return s


_VAR_PATTERN = re.compile(r"\(([a-zA-Z0-9_ \[\]:]+)\)")

_BORDER_VAL_MAP = {
    "single": "solid",
    "double": "double",
    "thinThickMediumGap": "double",
    "thickThinMediumGap": "double",
    "dotted": "dotted",
    "dashed": "dashed",
    "nil": "none",
    "none": "none",
}

_ONE_OFFER_DISABLED = {
    'company2', 'company3', 'company4', 'company5',
    'input4_budget_s', 'input5_budget_s', 'input6_budget_s', 'input7_budget_s',
    'input4_budget_f', 'input5_budget_f', 'input6_budget_f', 'input7_budget_f',
}

KEY_ALIASES = {
    # new → old aliases (backward compat: new templates with old form_data)
    'category': 'drop_downlist',
    'currency': 'drop_down_list_currency',
    'full_budget': 'input2_budget',
    'input_year': 'input',
    'percentage_page1': 'input_percentage_page1',
    'final_budget': 'input3_budget',
    'input_description': 'description_input',
    'list_member[0]': 'drop_down_list_member[0]',
    'list_member[1]': 'drop_down_list_ member[1]',
    'list_member[2]': 'drop_down_list_ member[2]',
    'list_member[3]': 'drop_down_list_ member[3]',
    # old → new aliases (for old templates with new form_data)
    'drop_down_list_ member[0]': 'list_member[0]',
    'drop_down_list_ member[1]': 'list_member[1]',
    'drop_down_list_ member[2]': 'list_member[2]',
    'drop_down_list_ member[3]': 'list_member[3]',
    'drop_down_list_member[0]': 'list_member[0]',
    'drop_down_list_member[1]': 'list_member[1]',
    'drop_down_list_member[2]': 'list_member[2]',
    'drop_down_list_member[3]': 'list_member[3]',
    'drop_downlist': 'category',
    'drop_down_list_currency': 'currency',
    'input2_budget': 'full_budget',
    'input': 'input_year',
    'input_percentage_page1': 'percentage_page1',
    'input3_budget': 'final_budget',
    # typo / legacy aliases
    'comapny2': 'company2',
    'input_percentage[0:100]': 'input_percentage_page1',
}

_ARABIC_DIGITS = str.maketrans('0123456789', '٠١٢٣٤٥٦٧٨٩')
_ARABIC_TO_WESTERN = str.maketrans('٠١٢٣٤٥٦٧٨٩', '0123456789')

_ALIGN_MAP = {
    "right": "text-align: right;",
    "left": "text-align: left;",
    "center": "text-align: center;",
    "both": "text-align: justify;",
}

_TWIPTS = 20  # twips to points
_EMUPTS = 12700  # EMU to points fraction


class PreviewRenderer:

    def render(self, contract, template_key=None, edit_mode=False, override_data=None):
        key = template_key or contract.template_name
        config = TEMPLATES_CONFIG.get(key, TEMPLATES_CONFIG["committee"])
        template_path = TEMPLATE_ROOT / config["file"]
        if not template_path.exists():
            return "<p>Template not found</p>"

        doc = Document(str(template_path))
        data = override_data if override_data is not None else (contract.form_data or {})
        parts = []

        for p in doc.paragraphs:
            html = self._render_paragraph(p, data, edit_mode)
            if html:
                parts.append(html)

        for table in doc.tables:
            html = self._render_table(table, data, edit_mode)
            if html:
                parts.append(html)

        landscape = config.get("landscape", False)
        page_border_css = self._page_border_css(doc)
        return self._wrap_html("\n".join(parts), edit_mode, page_border_css, landscape)

    # ── XML helpers ────────────────────────────────────────────────

    def _find(self, parent, tag):
        if parent is None:
            return None
        return parent.find(qn(tag))

    def _get(self, el, attr, default=None):
        if el is None:
            return default
        return el.get(qn(attr), default)

    def _pt(self, val):
        """Convert twips (twentieths of a point) to pt string."""
        if val is None:
            return None
        return f"{int(val) / _TWIPTS}pt"

    def _pt_sz(self, val):
        """Convert half-point size to pt string."""
        if val is None:
            return None
        return f"{int(val) / 2}pt"

    # ── Paragraph formatting ──────────────────────────────────────

    def _para_css(self, p):
        pPr = self._find(p._element, 'w:pPr')
        if pPr is None:
            return ""
        rules = []

        jc = self._find(pPr, 'w:jc')
        if jc is not None:
            val = self._get(jc, 'w:val')
            if val in _ALIGN_MAP:
                rules.append(_ALIGN_MAP[val])

        spacing = self._find(pPr, 'w:spacing')
        if spacing is not None:
            before = self._pt(self._get(spacing, 'w:before'))
            after = self._pt(self._get(spacing, 'w:after'))
            line = self._get(spacing, 'w:line')
            if before:
                rules.append(f"margin-top: {before};")
            if after:
                rules.append(f"margin-bottom: {after};")
            if line and int(line) > 0:
                rules.append(f"line-height: {int(line) / 240};")

        ind = self._find(pPr, 'w:ind')
        if ind is not None:
            left = self._pt(self._get(ind, 'w:left'))
            right = self._pt(self._get(ind, 'w:right'))
            firstLine = self._pt(self._get(ind, 'w:firstLine'))
            if left:
                rules.append(f"padding-right: {left};")
            if right:
                rules.append(f"padding-left: {right};")
            if firstLine:
                rules.append(f"text-indent: {firstLine};")

        pBdr = self._find(pPr, 'w:pBdr')
        if pBdr is not None:
            for side in ('top', 'left', 'bottom', 'right'):
                side_el = self._find(pBdr, f'w:{side}')
                if side_el is None:
                    continue
                rules.append(self._border_css(side, side_el, 'padding'))

        shd = self._find(pPr, 'w:shd')
        if shd is not None:
            fill = self._get(shd, 'w:fill')
            if fill and fill.lower() != 'auto':
                rules.append(f"background-color: #{fill};")

        return " ".join(rules)

    def _border_css(self, side, el, prefix="padding"):
        val = self._get(el, 'w:val')
        if not val or val in ('nil', 'none'):
            return ""
        sz = self._get(el, 'w:sz', '4')
        color = self._get(el, 'w:color', '000000')
        if color == 'auto':
            color = '000000'
        style = _BORDER_VAL_MAP.get(val, 'solid')
        pt = f"{int(sz) / 8}pt"
        return f"border-{side}: {pt} {style} #{color};"

    def _run_css(self, run):
        rPr = self._find(run._element, 'w:rPr')
        if rPr is None:
            return ""
        rules = []

        rFonts = self._find(rPr, 'w:rFonts')
        if rFonts is not None:
            ascii = self._get(rFonts, 'w:ascii')
            cs = self._get(rFonts, 'w:cs')
            font = ascii or cs
            if font:
                rules.append(f"font-family: '{font}';")

        sz = self._find(rPr, 'w:sz')
        if sz is not None:
            val = self._get(sz, 'w:val')
            if val:
                rules.append(f"font-size: {self._pt_sz(val)};")

        color = self._find(rPr, 'w:color')
        if color is not None:
            val = self._get(color, 'w:val')
            if val and val.lower() != 'auto':
                rules.append(f"color: #{val};")

        if run.bold:
            rules.append("font-weight: bold;")
        if run.italic:
            rules.append("font-style: italic;")

        spacing = self._find(rPr, 'w:spacing')
        if spacing is not None:
            val = self._get(spacing, 'w:val')
            if val:
                rules.append(f"letter-spacing: {int(val) / 20}pt;")

        return " ".join(rules)

    # ── Cell formatting ───────────────────────────────────────────

    def _cell_css(self, cell):
        tcPr = self._find(cell._element, 'w:tcPr')
        if tcPr is None:
            return "border: 1px solid #ccc; padding: 6px 8px;"
        rules = ["padding: 6px 8px;"]

        tcBorders = self._find(tcPr, 'w:tcBorders')
        if tcBorders is not None:
            has_border = False
            for side in ('top', 'left', 'bottom', 'right'):
                side_el = self._find(tcBorders, f'w:{side}')
                if side_el is None:
                    continue
                bc = self._border_css(side, side_el)
                if bc:
                    rules.append(bc)
                    has_border = True
            if not has_border:
                rules.append("border: 1px solid #ccc;")
        else:
            rules.append("border: 1px solid #ccc;")

        shd = self._find(tcPr, 'w:shd')
        if shd is not None:
            fill = self._get(shd, 'w:fill')
            if fill and fill.lower() != 'auto':
                rules.append(f"background-color: #{fill};")

        return " ".join(rules)

    def _cell_colspan(self, cell):
        tcPr = self._find(cell._element, 'w:tcPr')
        if tcPr is None:
            return 1
        gs = self._find(tcPr, 'w:gridSpan')
        if gs is None:
            return 1
        return int(self._get(gs, 'w:val', '1'))

    # ── Paragraph rendering ───────────────────────────────────────

    def _resolve_value(self, key, data):
        # If a company is selected as primary, use its value for company1
        if key == 'company1' and data:
            selected = data.get('_selected_company')
            if selected and selected != 'company1':
                sv = data.get(selected)
                if sv and str(sv).strip():
                    return sv
        exact = data.get(key)
        if exact and str(exact).strip():
            return exact
        norm = re.sub(r'\s+', '', key)
        if norm != key:
            nv = data.get(norm)
            if nv and str(nv).strip():
                return nv
        mapped = KEY_ALIASES.get(key) or KEY_ALIASES.get(norm)
        if mapped:
            av = data.get(mapped)
            if av and str(av).strip():
                return av
        return exact  # fallback to exact (even if empty) or None

    def _make_field(self, key, val, edit_mode, data=None):
        if edit_mode:
            input_val = str(val).translate(_ARABIC_TO_WESTERN) if val else ''
            inputmode = ''
            maxlength_attr = ''
            if key in ('date', 'date2'):
                input_type = 'date'
                input_val = _repair_corrupt_date(input_val).replace('/', '-')
            elif key == 'input_hour':
                input_type = 'text'
                input_val = input_val.replace(':', '')
                inputmode = ' inputmode="numeric"'
                maxlength_attr = ' maxlength="4"'
            elif key == 'isOneOffer':
                checked = ' checked' if input_val == 'True' else ''
                return f'<input type="checkbox" data-var="{key}" name="{key}" aria-label="{key}" value="True"{checked} class="var-input var-checkbox">'
            elif any(x in key for x in ('budget', 'percentage')):
                input_type = 'text'
                inputmode = ' inputmode="numeric"'
            else:
                input_type = 'text'
                inputmode = ''
            disabled = ' disabled' if (data and
                str(data.get('isOneOffer')) == 'True' and
                key in _ONE_OFFER_DISABLED) else ''
            safe = input_val.replace('"', '&quot;')
            return f'<input type="{input_type}"{inputmode}{maxlength_attr}{disabled} data-var="{key}" name="{key}" aria-label="{key}" value="{safe}" class="var-input">'
        if val and key in ('date', 'date2'):
            val = _format_date(val)
        elif key == 'input_hour':
            val = str(val).replace(':', '')
        display = str(val).translate(_ARABIC_DIGITS) if val else ''
        safe = display.replace('"', '&quot;')
        return f'<span class="var-value">{display}</span>'

    def _render_paragraph(self, p, data, edit_mode):
        full = p.text
        if not full.strip():
            return ""

        # Process conditional [if:key]...[end] blocks (segment-level)
        conditionals_modified = False
        if '[' in full:
            processed = full
            while True:
                m = re.search(r'\[if:(\w+)\]', processed)
                if not m:
                    break
                conditionals_modified = True
                var_key = m.group(1)
                var_val = self._resolve_value(var_key, data)
                end_idx = processed.find('[end]', m.end())

                before = processed[:m.start()]
                after = processed[end_idx + 5:] if end_idx >= 0 else ''
                content = processed[m.end():end_idx] if end_idx >= 0 else processed[m.end():]

                if var_val and str(var_val).strip():
                    processed = before + content + after
                else:
                    processed = before + after

            processed = re.sub(r'\[end\]', '', processed)
            if not processed.strip():
                return ""
            full = processed

        para_css = self._para_css(p)

        # Check if paragraph has variables
        if _VAR_PATTERN.search(full):
            # Consolidate runs: put all text in first run
            replaced = _VAR_PATTERN.sub(
                lambda m: self._make_field(m.group(1).strip(),
                    self._resolve_value(m.group(1).strip(), data) or '', edit_mode, data)
                if m.group(1).strip() else m.group(0),
                full
            )
            run_css = ""
            if p.runs:
                run_css = self._run_css(p.runs[0])
            inner = f'<span style="{run_css}">{replaced}</span>' if run_css else replaced
        else:
            if conditionals_modified:
                # Conditionals changed text across runs — use consolidated text
                txt = full
                rcss = self._run_css(p.runs[0]) if p.runs else ""
                inner = f'<span style="{rcss}">{txt}</span>' if rcss else txt
            else:
                # Preserve per-run formatting
                inner = ""
                for run in p.runs:
                    txt = run.text
                    if not txt.strip():
                        inner += txt
                        continue
                    rcss = self._run_css(run)
                    # Still check for variables in sub-run (edge case)
                    txt = _VAR_PATTERN.sub(
                        lambda m: self._make_field(m.group(1).strip(),
                            self._resolve_value(m.group(1).strip(), data) or '', edit_mode, data)
                        if m.group(1).strip() else m.group(0),
                        txt
                    )
                    if rcss:
                        inner += f'<span style="{rcss}">{txt}</span>'
                    else:
                        inner += txt
                if not inner:
                    return ""

        # Apply bold/italic/underline from any run as paragraph-level wrap
        wraps = []
        if any(run.bold for run in p.runs):
            wraps.append("strong")
        if any(run.italic for run in p.runs):
            wraps.append("em")
        if any(run.underline for run in p.runs):
            wraps.append("u")

        for tag in wraps:
            inner = f"<{tag}>{inner}</{tag}>"

        return f"<p style='{para_css}'>{inner}</p>"

    # ── Table rendering ──────────────────────────────────────────

    def _render_table(self, table, data, edit_mode):
        # Determine hidden company columns by resolving (companyN) in header row
        if table.rows:
            hidden_cols = set()
            seen = set()
            col_pos = 0
            for cell in table.rows[0].cells:
                eid = id(cell._tc)
                if eid in seen:
                    continue
                seen.add(eid)
                cs = self._cell_colspan(cell)
                m = re.search(r'\(company(\d+)\)', cell.text)
                if m:
                    company_key = f'company{m.group(1)}'
                    val = self._resolve_value(company_key, data)
                    if not val or not str(val).strip():
                        hidden_cols.update(range(col_pos, col_pos + cs))
                col_pos += cs
        else:
            hidden_cols = set()

        # Read original column widths from tblGrid (twips)
        col_widths = []
        tblGrid = table._tbl.find(qn('w:tblGrid'))
        if tblGrid is not None:
            for gc in tblGrid.findall(qn('w:gridCol')):
                w = gc.get(qn('w:w'))
                col_widths.append(int(w) if w else 0)

        # Compute total width of visible columns
        visible_total = sum(
            col_widths[i] for i in range(len(col_widths)) if i not in hidden_cols
        ) if col_widths else 0
        table_width = f"width: {(visible_total / 20):.1f}pt; " if visible_total else ""

        rows_html = []
        for row in table.rows:
            cells_html = []
            seen = set()
            col_pos = 0
            for cell in row.cells:
                eid = id(cell._tc)
                if eid in seen:
                    continue
                seen.add(eid)

                cs = self._cell_colspan(cell)
                cell_cols = set(range(col_pos, col_pos + cs))

                # Skip cell if all spanned columns are hidden
                if cell_cols.issubset(hidden_cols):
                    col_pos += cs
                    continue

                parts = []
                for p in cell.paragraphs:
                    rendered = self._render_paragraph(p, data, edit_mode)
                    if rendered:
                        parts.append(rendered)
                cell_html = "".join(parts) if parts else ""

                visible_count = len(cell_cols - hidden_cols)
                col_attr = f' colspan="{visible_count}"' if visible_count > 1 else ''
                cell_css = self._cell_css(cell)
                # Preserve original column widths for proporation (only visible columns)
                if col_widths:
                    visible_widths = [col_widths[c] for c in cell_cols if c < len(col_widths) and c not in hidden_cols]
                    span_width = sum(visible_widths) if visible_widths else 0
                    cell_css += f' width: {(span_width / 20):.1f}pt;'
                cells_html.append(
                    f"<td{col_attr} style='{cell_css}'>{cell_html}</td>"
                )
                col_pos += cs

            if cells_html:
                rows_html.append("<tr>" + "".join(cells_html) + "</tr>")
        return '<table style="border-collapse: collapse; ' + table_width + 'table-layout: fixed; word-wrap: break-word; overflow-wrap: break-word; margin: 8px 0;">' + "".join(rows_html) + "</table>"

    # ── Page borders ──────────────────────────────────────────────

    def _page_border_css(self, doc):
        lines = []
        try:
            sectPr = self._find(doc.sections[0]._sectPr, 'w:pgBorders')
            if sectPr is None:
                return ""
            for side in ('top', 'left', 'bottom', 'right'):
                el = self._find(sectPr, f'w:{side}')
                if el is None:
                    continue
                lines.append(self._border_css(side, el))
        except Exception:
            pass
        if lines:
            return "\n".join("    " + l for l in lines if l)
        return ""

    # ── Wrapper ───────────────────────────────────────────────────

    def _wrap_html(self, body, edit_mode=False, page_border_css="", landscape=False):
        ie_css = ""
        if edit_mode:
            ie_css = """
  .var-input {
    border: 0;
    border-bottom: 2px dashed #cb0101;
    background: transparent;
    color: #cb0101;
    font-weight: 600;
    text-align: center;
    font-family: inherit;
    font-size: inherit;
    outline: none;
    min-width: 90px;
    width: auto;
    display: inline-block;
    margin: 0 2px;
    padding: 0 4px;
  }
  .var-input:focus {
    border-bottom-color: #cb010185;
  }
  td .var-input {
    max-width: 100%;
    box-sizing: border-box;
  }"""
        else:
            ie_css = """
  .var-value {
    color: #cb0101;
    font-weight: 600;
  }"""
        border_style = f"\n{page_border_css}" if page_border_css else ""
        if landscape:
            max_w = "330mm"
            min_h = "210mm"
            pad = "15mm 20mm"
            print_page = "size: landscape;"
        else:
            max_w = "210mm"
            min_h = "297mm"
            pad = "20mm 15mm"
            print_page = ""
        return f"""<style>
  .document-container * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  .document-container {{
    font-family: 'Times New Roman', 'Traditional Arabic', serif;
    direction: rtl;
    max-width: {max_w};
    overflow-x: auto;
    margin: 0 auto;
    background: #fff;
    padding: {pad};
    box-shadow: 0 1px 6px rgba(0,0,0,0.15);
    min-height: {min_h};{border_style}
  }}
  .document-container p {{
    margin: 0;
  }}
  @media print {{
    .document-container {{
      box-shadow: none;
      padding: {pad};
      max-width: 100%;
    }}
    @page {{ {print_page} }}
  }}{ie_css}
</style>
<div class="document-container">
{body}</div>"""