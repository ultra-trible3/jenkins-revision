from django.urls import path
from . import views_dashboard

urlpatterns = [
    path("stats/", views_dashboard.dashboard_stats, name="dashboard-stats"),
    path("committee-stats/", views_dashboard.committee_stats, name="committee-stats"),
]
