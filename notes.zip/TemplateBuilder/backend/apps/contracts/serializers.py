from rest_framework import serializers
from .models import Contract, ContractType, ContractDownload, Company, CommitteeMember, Entity, ContractAttachment


class ContractTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContractType
        fields = ["id", "name"]


class ContractListSerializer(serializers.ModelSerializer):
    contract_type = ContractTypeSerializer(read_only=True)
    contract_type_id = serializers.IntegerField(write_only=True, required=False, allow_null=True)
    parent_committee_number = serializers.CharField(source='parent_committee.contract_number', read_only=True, default=None)
    children_count = serializers.SerializerMethodField()

    class Meta:
        model = Contract
        fields = [
            "id",
            "contract_number",
            "template_name",
            "contract_type",
            "contract_type_id",
            "parent_committee",
            "parent_committee_number",
            "children_count",
            "created_at",
            "updated_at",
        ]

    def get_children_count(self, obj):
        return obj.child_contracts.count()


class ContractDetailSerializer(serializers.ModelSerializer):
    contract_type = ContractTypeSerializer(read_only=True)
    contract_type_id = serializers.IntegerField(write_only=True, required=False, allow_null=True)
    children = serializers.SerializerMethodField()

    class Meta:
        model = Contract
        fields = [
            "id",
            "contract_number",
            "template_name",
            "contract_type",
            "contract_type_id",
            "form_data",
            "parent_committee",
            "children",
            "created_by",
            "created_at",
            "updated_at",
        ]
        read_only_fields = [
            "id",
            "contract_number",
            "created_by",
            "created_at",
            "updated_at",
        ]

    def get_children(self, obj):
        children = obj.child_contracts.all()
        return ContractListSerializer(children, many=True, context=self.context).data


class ContractDownloadSerializer(serializers.ModelSerializer):
    contract_id = serializers.IntegerField(source="contract.id", read_only=True)

    class Meta:
        model = ContractDownload
        fields = [
            "id",
            "contract_id",
            "contract_number",
            "file_type",
            "downloaded_at",
            "user",
        ]


class CompanySerializer(serializers.ModelSerializer):
    class Meta:
        model = Company
        fields = ["id", "name", "is_active", "created_at", "updated_at"]
        read_only_fields = ["created_at", "updated_at"]


class CommitteeMemberSerializer(serializers.ModelSerializer):
    role_display = serializers.CharField(source='get_role_display', read_only=True)

    class Meta:
        model = CommitteeMember
        fields = ["id", "name", "role", "role_display", "is_active", "created_at", "updated_at"]
        read_only_fields = ["created_at", "updated_at"]


class EntitySerializer(serializers.ModelSerializer):
    class Meta:
        model = Entity
        fields = ["id", "name", "is_active", "created_at", "updated_at"]
        read_only_fields = ["created_at", "updated_at"]


class ContractAttachmentSerializer(serializers.ModelSerializer):
    url = serializers.SerializerMethodField()

    class Meta:
        model = ContractAttachment
        fields = ["id", "contract", "file", "url", "original_name", "file_type", "file_size", "uploaded_at"]
        read_only_fields = ["original_name", "file_type", "file_size", "uploaded_at"]

    def get_url(self, obj):
        request = self.context.get("request")
        if obj.file and request:
            return request.build_absolute_uri(obj.file.url)
        return obj.file.url if obj.file else None
