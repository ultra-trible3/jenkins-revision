from django.contrib import admin
from .models import (
    Contract, ContractType, ContractTypeTemplate, ContractDownload,
    Company, CommitteeMember, Entity, ContractAttachment,
)


@admin.register(ContractType)
class ContractTypeAdmin(admin.ModelAdmin):
    list_display = ["name", "created_at"]
    search_fields = ["name"]


@admin.register(ContractTypeTemplate)
class ContractTypeTemplateAdmin(admin.ModelAdmin):
    list_display = ["contract_type", "template_key"]
    list_filter = ["contract_type"]


@admin.register(Contract)
class ContractAdmin(admin.ModelAdmin):
    list_display = [
        "contract_number",
        "template_name",
        "contract_type",
        "parent_committee",
        "created_by",
        "created_at",
    ]
    list_filter = ["template_name", "contract_type", "created_at"]
    search_fields = ["contract_number"]
    raw_id_fields = ["contract_type", "created_by", "parent_committee"]
    readonly_fields = ["created_at", "updated_at"]


@admin.register(ContractDownload)
class ContractDownloadAdmin(admin.ModelAdmin):
    list_display = ["contract_number", "file_type", "user", "downloaded_at"]
    list_filter = ["file_type", "downloaded_at"]
    search_fields = ["contract_number"]


@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ["name", "is_active", "created_at"]
    list_filter = ["is_active"]
    search_fields = ["name"]


@admin.register(CommitteeMember)
class CommitteeMemberAdmin(admin.ModelAdmin):
    list_display = ["name", "role", "is_active", "created_at"]
    list_filter = ["role", "is_active"]
    search_fields = ["name"]


@admin.register(Entity)
class EntityAdmin(admin.ModelAdmin):
    list_display = ["name", "is_active", "created_at"]
    list_filter = ["is_active"]
    search_fields = ["name"]


@admin.register(ContractAttachment)
class ContractAttachmentAdmin(admin.ModelAdmin):
    list_display = ["original_name", "contract", "file_type", "file_size", "uploaded_at"]
    list_filter = ["file_type", "uploaded_at"]
    search_fields = ["original_name"]
    raw_id_fields = ["contract"]
