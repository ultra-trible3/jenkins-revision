import { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { LayoutDashboard, FileText, PlusCircle, LogOut, FileSpreadsheet, ChevronDown, List, ChevronLeft, Download, Building2, Users, Landmark, ClipboardList } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

export default function Sidebar({ collapsed, onToggle }) {
  const { user, logout } = useAuth();
  const location = useLocation();
  const [expandedContracts, setExpandedContracts] = useState(true);
  const [expandedCommittees, setExpandedCommittees] = useState(true);

  const isContractsActive = ['/contracts', '/committees', '/companies', '/members', '/entities'].some(p => location.pathname.startsWith(p));

  return (
    <aside className={`fixed right-0 top-0 h-full bg-primary-800 text-white transition-all duration-300 z-50 flex flex-col ${collapsed ? 'w-16' : 'w-64'}`}>

      <div className="flex items-center h-16 px-4 border-b border-primary-700">
        {!collapsed && (
          <div className="flex items-center gap-2">
            <FileSpreadsheet size={24} className="text-primary-300" />
            <span className="font-bold text-md">نظام عقود القسم المالي</span>
          </div>
        )}
        <button onClick={onToggle} className={`text-white/70 hover:text-white ${collapsed ? 'mx-auto' : 'mr-auto'}`}>
          <svg className="w-5 h-5 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={collapsed ? "M13 5l7 7-7 7M5 5l7 7-7 7" : "M11 19l-7-7 7-7m8 14l-7-7 7-7"} />
          </svg>
        </button>
      </div>

      <nav className="flex-1 py-4 overflow-y-auto">
        <NavLink
          to="/dashboard"
          end
          className={({ isActive }) =>
            `flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition-colors ${isActive ? 'bg-primary-700 text-white' : 'text-primary-200 hover:bg-primary-700/50 hover:text-white'} ${collapsed ? 'justify-center mx-1' : ''}`
          }
        >
          <LayoutDashboard size={20} />
          {!collapsed && <span>لوحة التحكم</span>}
        </NavLink>

        {collapsed ? (
          <NavLink
            to="/contracts"
            end
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition-colors ${isActive ? 'bg-primary-700 text-white' : 'text-primary-200 hover:bg-primary-700/50 hover:text-white'} justify-center mx-1`
            }
          >
            <FileText size={20} />
          </NavLink>
        ) : (
          <div>
            <button
              onClick={() => setExpandedContracts(!expandedContracts)}
              className={`flex items-center gap-3 w-full px-4 py-3 mx-2 rounded-lg transition-colors ${isContractsActive ? 'bg-primary-700 text-white' : 'text-primary-200 hover:bg-primary-700/50 hover:text-white'}`}
              style={{ width: 'calc(100% - 16px)' }}
            >
              <FileText size={20} />
              <span className="flex-1 text-right">العقود</span>
              <ChevronDown size={16} className={`transition-transform ${expandedContracts ? 'rotate-0' : '-rotate-90'}`} />
            </button>
            {expandedContracts && (
              <div className="mr-4 border-r border-primary-600 pr-2 pt-2 space-y-1">
                <button
                  onClick={() => setExpandedCommittees(!expandedCommittees)}
                  className={`flex items-center gap-3 w-full px-4 py-2 mx-2 rounded-lg transition-colors text-sm ${isContractsActive ? 'bg-primary-700/50 text-white' : 'text-primary-200 hover:bg-primary-700/50 hover:text-white'}`}
                  style={{ width: 'calc(100% - 16px)' }}
                >
                  <ClipboardList size={16} />
                  <span className="flex-1 text-right">لجان الممارسة</span>
                  <ChevronDown size={14} className={`transition-transform ${expandedCommittees ? 'rotate-0' : '-rotate-90'}`} />
                </button>
                {expandedCommittees && (
                  <div className="mr-4 border-r border-primary-500 pr-2 pt-1 space-y-1">
                    <NavLink
                      to="/committees"
                      className={({ isActive }) =>
                        `flex items-center gap-3 px-3 py-2 mx-2 rounded-lg transition-colors text-xs ${isActive ? 'bg-primary-700 text-white' : 'text-primary-300 hover:bg-primary-700/50 hover:text-white'}`
                      }
                    >
                      <ClipboardList size={14} />
                      <span>لوحة لجان الممارسة</span>
                    </NavLink>
                    <NavLink
                      to="/contracts"
                      end
                      className={({ isActive }) =>
                        `flex items-center gap-3 px-3 py-2 mx-2 rounded-lg transition-colors text-xs ${isActive ? 'bg-primary-700 text-white' : 'text-primary-300 hover:bg-primary-700/50 hover:text-white'}`
                      }
                    >
                      <List size={14} />
                      <span>قائمة العقود</span>
                    </NavLink>
                    <NavLink
                      to="/contracts/new/editor?contract_type=1"
                      className={({ isActive }) =>
                        `flex items-center gap-3 px-3 py-2 mx-2 rounded-lg transition-colors text-xs ${isActive ? 'bg-primary-700 text-white' : 'text-primary-300 hover:bg-primary-700/50 hover:text-white'}`
                      }
                    >
                      <PlusCircle size={14} />
                      <span>إنشاء لجنة ممارسة</span>
                    </NavLink>
                    <NavLink
                      to="/contracts/downloads"
                      className={({ isActive }) =>
                        `flex items-center gap-3 px-3 py-2 mx-2 rounded-lg transition-colors text-xs ${isActive ? 'bg-primary-700 text-white' : 'text-primary-300 hover:bg-primary-700/50 hover:text-white'}`
                      }
                    >
                      <Download size={14} />
                      <span>سجل التحميلات</span>
                    </NavLink>
                    <NavLink
                      to="/companies"
                      className={({ isActive }) =>
                        `flex items-center gap-3 px-3 py-2 mx-2 rounded-lg transition-colors text-xs ${isActive ? 'bg-primary-700 text-white' : 'text-primary-300 hover:bg-primary-700/50 hover:text-white'}`
                      }
                    >
                      <Building2 size={14} />
                      <span>إضافة شركات</span>
                    </NavLink>
                    <NavLink
                      to="/members"
                      className={({ isActive }) =>
                        `flex items-center gap-3 px-3 py-2 mx-2 rounded-lg transition-colors text-xs ${isActive ? 'bg-primary-700 text-white' : 'text-primary-300 hover:bg-primary-700/50 hover:text-white'}`
                      }
                    >
                      <Users size={14} />
                      <span>أعضاء اللجنة</span>
                    </NavLink>
                    <NavLink
                      to="/entities"
                      className={({ isActive }) =>
                        `flex items-center gap-3 px-3 py-2 mx-2 rounded-lg transition-colors text-xs ${isActive ? 'bg-primary-700 text-white' : 'text-primary-300 hover:bg-primary-700/50 hover:text-white'}`
                      }
                    >
                      <Landmark size={14} />
                      <span>الجهات</span>
                    </NavLink>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

      </nav>

      <div className="border-t border-primary-700 p-4 space-y-3">
        <div className={`flex items-center gap-3 text-primary-200 ${collapsed ? 'justify-center' : ''}`}>
          <div className="w-8 h-8 rounded-full bg-primary-600 text-white flex items-center justify-center text-sm font-bold shrink-0">
            {user?.username?.charAt(0)?.toUpperCase() || 'A'}
          </div>
          {!collapsed && <span className="text-sm font-medium truncate">{user?.username || 'Admin'}</span>}
        </div>
        <button
          onClick={logout}
          className={`flex items-center gap-3 text-primary-200 hover:text-white transition-colors w-full ${collapsed ? 'justify-center' : ''}`}
        >
          <LogOut size={20} />
          {!collapsed && <span>تسجيل الخروج</span>}
        </button>
      </div>
    </aside>
  );
}
