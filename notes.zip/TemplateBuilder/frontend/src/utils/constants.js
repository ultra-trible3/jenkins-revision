export const ROLES = {
  ADMIN: 'admin',
};

export const CONTRACT_STATUS = {
  ACTIVE: 'active',
  EXPIRED: 'expired',
  TERMINATED: 'terminated',
};
