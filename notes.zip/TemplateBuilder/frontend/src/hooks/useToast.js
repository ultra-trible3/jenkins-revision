import { useMemo } from 'react';
import { toast } from 'react-hot-toast';

export function useToast() {
  return useMemo(() => ({
    success: (message) => toast.success(message, {
      iconTheme: {
        primary: '#16a34a',
        secondary: '#FFFAEE',
      }
    }),
    error: (message) => toast.error(message, {
      iconTheme: {
        primary: 'red',
        secondary: '#FFFAEE',
      }
    }),
    info: (message) => toast(message),
  }), []);
}
