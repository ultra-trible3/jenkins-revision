import api from './api';

export const contractService = {
  list: (params) => api.get('/contracts/', { params }),

  get: (id) => api.get(`/contracts/${id}/`),

  create: (data) => api.post('/contracts/', data),

  update: (id, data) => api.patch(`/contracts/${id}/`, data),

  delete: (id) => api.delete(`/contracts/${id}/`),

  duplicate: (id, parentId) => {
    const body = parentId ? { parent_committee_id: parentId } : {};
    return api.post(`/contracts/${id}/duplicate/`, body);
  },

  getChildren: (id) => api.get(`/contracts/${id}/children/`),

  downloadWord: (id, template) =>
    api.get(`/contracts/${id}/word/`, { params: { template }, responseType: 'blob' }),

  downloadPdf: (id, template) =>
    api.get(`/contracts/${id}/pdf/`, { params: { template }, responseType: 'blob' }),

  stats: () => api.get('/dashboard/stats/'),

  committeeStats: () => api.get('/dashboard/committee-stats/'),

  listTemplates: () => api.get('/contracts/templates/'),

  listContractTypes: () => api.get('/contracts/contract_types/'),

  preview: (id, template, mode) => api.get(`/contracts/${id}/preview/`, { params: { template, mode } }),

  previewWithData: (id, template, mode, formData) =>
    api.post(`/contracts/${id}/preview/`, { form_data: formData }, { params: { template, mode } }),

  getDownloadHistory: (params) => api.get('/contracts/download_history/', { params }),

  openStorageFolder: (id) => api.get(`/contracts/${id}/open_storage_folder/`),

  listCompanies: (params) => api.get('/companies/', { params }),

  createCompany: (data) => api.post('/companies/', data),

  updateCompany: (id, data) => api.patch(`/companies/${id}/`, data),

  deleteCompany: (id) => api.delete(`/companies/${id}/`),

  listMembers: (params) => api.get('/members/', { params }),

  createMember: (data) => api.post('/members/', data),

  updateMember: (id, data) => api.patch(`/members/${id}/`, data),

  deleteMember: (id) => api.delete(`/members/${id}/`),

  listEntities: (params) => api.get('/entities/', { params }),

  createEntity: (data) => api.post('/entities/', data),

  updateEntity: (id, data) => api.patch(`/entities/${id}/`, data),

  deleteEntity: (id) => api.delete(`/entities/${id}/`),

  listAttachments: (contractId) => api.get('/attachments/', { params: { contract_id: contractId } }),

  listPendingAttachments: () => api.get('/attachments/', { params: { contract_id: '' } }),

  uploadAttachment: (contractId, file) => {
    const formData = new FormData();
    formData.append('file', file);
    if (contractId) formData.append('contract', contractId);
    return api.post('/attachments/', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },

  attachToContract: (attachmentId, contractId) => {
    return api.patch(`/attachments/${attachmentId}/`, { contract: contractId });
  },

  deleteAttachment: (id) => api.delete(`/attachments/${id}/`),
};
