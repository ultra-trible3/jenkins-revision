import api from './api';

export const authService = {
  login: (username, password) =>
    api.post('/auth/login/', { username, password }),

  logout: (refreshToken) =>
    api.post('/auth/logout/', { refresh: refreshToken }),

  refresh: (refreshToken) =>
    api.post('/auth/refresh/', { refresh: refreshToken }),
};
