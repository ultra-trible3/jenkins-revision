import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './context/AuthContext';
import MainLayout from './layouts/MainLayout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import ContractsList from './pages/ContractsList';
import EditContract from './pages/EditContract';
import ContractViewer from './pages/ContractViewer';
import DownloadHistory from './pages/DownloadHistory';
import Companies from './pages/Companies';
import Members from './pages/Members';
import Entities from './pages/Entities';
import CommitteesDashboard from './pages/CommitteesDashboard';
import NotFound from './pages/NotFound';

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Toaster
          position="top-center"
          toastOptions={{
            duration: 3000,
            style: {
              fontSize: '14px',
              fontFamily: 'Segoe UI, system-ui, sans-serif',
              borderRadius: '10px',
              background: '#333',
              color: '#fff',
            },
          }}
        />
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route element={<MainLayout />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/contracts" element={<ContractsList />} />
            <Route path="/contracts/downloads" element={<DownloadHistory />} />
            <Route path="/contracts/new" element={<Navigate to="/contracts/new/editor" replace />} />
            <Route path="/contracts/new/editor" element={<EditContract />} />
            <Route path="/contracts/:id" element={<ContractViewer />} />
            <Route path="/contracts/:id/edit" element={<EditContract />} />
            <Route path="/companies" element={<Companies />} />
            <Route path="/members" element={<Members />} />
            <Route path="/entities" element={<Entities />} />
            <Route path="/committees" element={<CommitteesDashboard />} />
          </Route>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}

