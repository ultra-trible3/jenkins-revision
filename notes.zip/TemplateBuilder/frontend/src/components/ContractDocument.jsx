import { useRef } from 'react';

function InlineInput({ value, onChange, className = '', style = {}, placeholder = '' }) {
  return (
    <input
      type="text"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className={`inline-block border-0 border-b-2 border-dashed border-primary-400 bg-transparent text-center text-primary-700 font-semibold focus:outline-none focus:border-primary-600 transition-colors mx-1 ${className}`}
      style={{ minWidth: '120px', ...style }}
    />
  );
}

function InlineDate({ value, onChange }) {
  return (
    <input
      type="date"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="inline-block border-0 border-b-2 border-dashed border-primary-400 bg-transparent text-center text-primary-700 font-semibold focus:outline-none focus:border-primary-600 transition-colors mx-1"
      style={{ minWidth: '150px', width: 'auto' }}
    />
  );
}

function InlineCurrency({ value, onChange }) {
  return (
    <span className="inline-flex items-center gap-1">
      <input
        type="number"
        step="0.01"
        min="0"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="inline-block border-0 border-b-2 border-dashed border-primary-400 bg-transparent text-center text-primary-700 font-semibold focus:outline-none focus:border-primary-600 transition-colors mx-1"
        style={{ minWidth: '100px', width: '100px' }}
      />
      <span className="text-sm text-gray-500">ريال</span>
    </span>
  );
}

function StaticText({ children, className = '' }) {
  return <span className={className}>{children}</span>;
}

function Section({ title, children }) {
  return (
    <div className="mb-6">
      <h3 className="text-base font-bold text-gray-900 mb-3 text-right">{title}</h3>
      {children}
    </div>
  );
}

export default function ContractDocument({ data, editable, onChange }) {
  const docRef = useRef(null);

  const handleChange = (field) => (value) => {
    if (onChange) {
      onChange({ ...data, [field]: value });
    }
  };

  const inputCls = 'w-40 sm:w-48';
  const bigInputCls = 'w-60 sm:w-72';

  return (
    <div ref={docRef} className="contract-document">
      <div className="max-w-[210mm] mx-auto bg-white shadow-lg" style={{ minHeight: '297mm' }}>
        <div className="p-8 sm:p-12">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="text-3xl font-bold text-gray-900 mb-1">عقد إيجار</div>
            <div className="text-lg text-gray-500 mb-4">{'＿'.repeat(20)}</div>
            <div className="text-xl text-gray-700 mb-6">بسم الله الرحمن الرحيم</div>
          </div>

          {/* Preamble */}
          <div className="mb-6">
            <p className="text-sm text-gray-700 leading-relaxed mb-4 text-right font-bold">
              تم الاتفاق والتراضي بين كل من:
            </p>
          </div>

          {/* Party 1 - Owner */}
          <div className="mb-3 text-right">
            <span className="font-bold text-gray-800">الطرف الأول (المؤجر): </span>
            {editable ? (
              <InlineInput
                value={data.owner_name}
                onChange={handleChange('owner_name')}
                className={bigInputCls}
                placeholder="اسم المالك"
              />
            ) : (
              <StaticText className="font-semibold text-gray-900 border-b-2 border-primary-200 px-2">
                {data.owner_name}
              </StaticText>
            )}
          </div>

          {/* Party 2 - Tenant */}
          <div className="mb-3 text-right">
            <span className="font-bold text-gray-800">الطرف الثاني (المستأجر): </span>
            {editable ? (
              <InlineInput
                value={data.tenant_name}
                onChange={handleChange('tenant_name')}
                className={bigInputCls}
                placeholder="اسم المستأجر"
              />
            ) : (
              <StaticText className="font-semibold text-gray-900 border-b-2 border-primary-200 px-2">
                {data.tenant_name}
              </StaticText>
            )}
          </div>

          {/* National ID */}
          <div className="mb-3 text-right">
            <span className="font-bold text-gray-800">رقم الهوية الوطنية: </span>
            {editable ? (
              <InlineInput
                value={data.national_id}
                onChange={handleChange('national_id')}
                className={inputCls}
                placeholder="رقم الهوية"
              />
            ) : (
              <StaticText className="font-semibold text-gray-900 border-b-2 border-primary-200 px-2">
                {data.national_id}
              </StaticText>
            )}
          </div>

          {/* Contract Date */}
          <div className="mb-6 text-right">
            <span className="font-bold text-gray-800">تاريخ العقد: </span>
            {editable ? (
              <InlineDate value={data.contract_date} onChange={handleChange('contract_date')} />
            ) : (
              <StaticText className="font-semibold text-gray-900 border-b-2 border-primary-200 px-2">
                {data.contract_date || '—'}
              </StaticText>
            )}
          </div>

          <div className="border-t border-gray-200 my-6" />

          {/* Section 1 */}
          <Section title="المادة الأولى: توصيف العين المؤجرة">
            <div className="text-right mb-3">
              <span className="font-bold text-gray-800">عنوان الشقة: </span>
              {editable ? (
                <InlineInput
                  value={data.apartment_address}
                  onChange={handleChange('apartment_address')}
                  className={bigInputCls}
                  placeholder="عنوان الشقة"
                />
              ) : (
                <StaticText className="font-semibold text-gray-900 border-b-2 border-primary-200 px-2">
                  {data.apartment_address}
                </StaticText>
              )}
            </div>

            <div className="flex gap-8 mb-3 justify-end">
              <div className="text-right">
                <span className="font-bold text-gray-800">رقم الشقة: </span>
                {editable ? (
                  <InlineInput
                    value={data.apartment_number}
                    onChange={handleChange('apartment_number')}
                    className="w-24"
                    placeholder="رقم"
                  />
                ) : (
                  <StaticText className="font-semibold text-gray-900 border-b-2 border-primary-200 px-2">
                    {data.apartment_number}
                  </StaticText>
                )}
              </div>
              <div className="text-right">
                <span className="font-bold text-gray-800">الدور: </span>
                {editable ? (
                  <InlineInput
                    value={data.floor}
                    onChange={handleChange('floor')}
                    className="w-24"
                    placeholder="الدور"
                  />
                ) : (
                  <StaticText className="font-semibold text-gray-900 border-b-2 border-primary-200 px-2">
                    {data.floor}
                  </StaticText>
                )}
              </div>
            </div>

            <p className="text-sm text-gray-600 leading-relaxed text-right">
              تعتبر العين المؤجرة بكامل ملحقاتها وتركيباتها جزءاً لا يتجزأ من هذا العقد.
            </p>
          </Section>

          {/* Section 2 */}
          <Section title="المادة الثانية: مدة الإيجار">
            <p className="text-sm text-gray-700 leading-relaxed text-right">
              تبدأ مدة الإيجار من تاريخ{' '}
              {editable ? (
                <InlineDate value={data.start_date} onChange={handleChange('start_date')} />
              ) : (
                <StaticText className="font-semibold text-gray-900 border-b-2 border-primary-200 px-2">
                  {data.start_date || '—'}
                </StaticText>
              )}
              {' '}وتنتهي في تاريخ{' '}
              {editable ? (
                <InlineDate value={data.end_date} onChange={handleChange('end_date')} />
              ) : (
                <StaticText className="font-semibold text-gray-900 border-b-2 border-primary-200 px-2">
                  {data.end_date || '—'}
                </StaticText>
              )}
              .
            </p>
          </Section>

          {/* Section 3 */}
          <Section title="المادة الثالثة: قيمة الإيجار">
            <div className="text-right mb-2">
              <span className="font-bold text-gray-800">قيمة الإيجار الشهري: </span>
              {editable ? (
                <InlineCurrency value={data.monthly_rent} onChange={handleChange('monthly_rent')} />
              ) : (
                <StaticText className="font-semibold text-gray-900 border-b-2 border-primary-200 px-2">
                  {Number(data.monthly_rent).toLocaleString()} ريال
                </StaticText>
              )}
            </div>
            <div className="text-right mb-2">
              <span className="font-bold text-gray-800">التأمين: </span>
              {editable ? (
                <InlineCurrency value={data.deposit} onChange={handleChange('deposit')} />
              ) : (
                <StaticText className="font-semibold text-gray-900 border-b-2 border-primary-200 px-2">
                  {Number(data.deposit).toLocaleString()} ريال
                </StaticText>
              )}
            </div>
            <p className="text-sm text-gray-600 leading-relaxed text-right">
              يتم سداد الإيجار في اليوم الأول من كل شهر، ويحصل المستأجر على إيصال معتمد بذلك.
            </p>
          </Section>

          {/* Sections 4-6 */}
          <Section title="المادة الرابعة: التزامات المستأجر">
            <ol className="text-sm text-gray-700 leading-relaxed space-y-1 list-decimal list-inside text-right">
              <li>يلتزم المستأجر بدفع الإيجار في مواعيده المتفق عليها.</li>
              <li>يلتزم المستأجر بالمحافظة على العين المؤجرة واستعمالها استعمالاً أميناً.</li>
              <li>لا يحق للمستأجر التأجير من الباطن أو التنازل عن العقد دون موافقة المؤجر الخطية.</li>
              <li>يلتزم المستأجر بدفع فواتير الخدمات (الكهرباء، الماء، الغاز).</li>
            </ol>
          </Section>

          <Section title="المادة الخامسة: التزامات المؤجر">
            <ol className="text-sm text-gray-700 leading-relaxed space-y-1 list-decimal list-inside text-right">
              <li>يلتزم المؤجر بتسليم العين المؤجرة للمستأجر في حالة صالحة للاستعمال.</li>
              <li>يلتزم المؤجر بإجراء الصيانة الأساسية للعين المؤجرة.</li>
              <li>يضمن المؤجر أن العين المؤجرة خالية من المنازعات القانونية.</li>
            </ol>
          </Section>

          <Section title="المادة السادسة: فسخ العقد">
            <p className="text-sm text-gray-700 leading-relaxed text-right">
              يحق لكل من الطرفين فسخ العقد بعد إشعار الطرف الآخر قبل 30 يوماً من تاريخ الإخلاء،
              مع الالتزام بكافة الشروط المتفق عليها.
            </p>
          </Section>

          {/* Notes */}
          <div className="mt-6 pt-4 border-t border-gray-200">
            <div className="text-right">
              <span className="font-bold text-gray-800">ملاحظات: </span>
              {editable ? (
                <textarea
                  value={data.notes}
                  onChange={(e) => handleChange('notes')(e.target.value)}
                  placeholder="ملاحظات إضافية..."
                  rows={2}
                  className="inline-block align-top border-0 border-b-2 border-dashed border-primary-400 bg-transparent text-gray-700 focus:outline-none focus:border-primary-600 resize-none mx-1"
                  style={{ minWidth: '300px', width: 'auto' }}
                />
              ) : (
                <StaticText className="text-gray-700">{data.notes || '—'}</StaticText>
              )}
            </div>
          </div>

          {/* Contract Number Reference */}
          <div className="mt-6 text-right text-xs text-gray-400">
            <span>رقم العقد: </span>
            <span className="font-semibold">{data.contract_number}</span>
          </div>

          {/* Signature Section */}
          <div className="mt-16 pt-8 border-t border-gray-200">
            <div className="flex justify-between">
              <div className="text-center">
                <div className="text-gray-400 mb-1">{'＿'.repeat(15)}</div>
                <div className="text-sm font-bold text-gray-700">توقيع الطرف الأول (المؤجر)</div>
              </div>
              <div className="text-center">
                <div className="text-gray-400 mb-1">{'＿'.repeat(15)}</div>
                <div className="text-sm font-bold text-gray-700">توقيع الطرف الثاني (المستأجر)</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
