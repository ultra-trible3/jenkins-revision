export default function CurrencyInput({ value, onChange, error, ...props }) {
  return (
    <div>
      <div className={`flex items-center border rounded-lg overflow-hidden focus-within:ring-2 focus-within:ring-primary-500 focus-within:border-primary-500 ${error ? 'border-red-500' : 'border-gray-300'}`}>
        <span className="px-3 py-2 bg-gray-50 text-gray-500 text-sm border-l">ريال</span>
        <input
          type="number"
          step="0.01"
          min="0"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full px-3 py-2 outline-none text-sm"
          {...props}
        />
      </div>
      {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
    </div>
  );
}
