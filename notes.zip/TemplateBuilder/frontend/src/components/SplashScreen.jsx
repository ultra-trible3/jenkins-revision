import { useEffect } from 'react';

export default function SplashScreen({ onComplete }) {
  useEffect(() => {
    const timer = setTimeout(onComplete, 3500);
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-50 bg-linear-to-br from-primary-800 via-primary-700 to-primary-900 flex items-center justify-center">
      <style>{`
        @keyframes splashFadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes splashSpin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes splashSlideRight {
          from { transform: translateX(0); }
          to { transform: translateX(60px); }
        }
        @keyframes splashRevealText {
          from { clip-path: inset(0 100% 0 0); }
          to { clip-path: inset(0 0 0 0); }
        }
        .splash-logo {
          animation:
            splashFadeIn 0.6s ease-out forwards,
            splashSpin 1s 0.6s ease-in-out forwards;
          opacity: 0;
          width: 160px;
          height: 160px;
          object-fit: contain;
        }
        .splash-slide {
          animation: splashSlideRight 0.8s 1.6s ease-out forwards;
          display: flex;
          align-items: center;
          gap: 24px;
        }
        .splash-text {
          animation: splashRevealText 0.6s 2.2s ease-out forwards;
          clip-path: inset(0 100% 0 0);
          color: white;
        }
      `}</style>
      <div className="splash-slide">
        <img src="/logo.png" alt="logo" className="splash-logo" />
        <div className="splash-text">
          <div style={{ fontWeight: 700, fontSize: '1.6rem', letterSpacing: '0.15em' }}>POWERED BY</div>
          <div style={{ fontSize: '1.4rem', marginTop: 8 }}>
            <span style={{ fontWeight: 500 }}>Information System</span>
            <span style={{ fontWeight: 300, opacity: 0.6, fontSize: '1.1rem' }}> Department</span>
          </div>
        </div>
      </div>
    </div>
  );
}
