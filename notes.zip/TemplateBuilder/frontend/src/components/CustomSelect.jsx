import { useState, useRef, useEffect } from 'react';
import { ChevronDown } from 'lucide-react';

function normalizeOptions(options) {
  return options.map((opt) => {
    if (opt && typeof opt === 'object' && !Array.isArray(opt)) {
      return { value: opt.id ?? opt.value ?? opt, label: opt.label ?? opt.id ?? opt };
    }
    return { value: opt, label: opt };
  });
}

export default function CustomSelect({ value, options, onChange, size = 'md', className = '' }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const items = normalizeOptions(options);
  const selected = items.find((o) => o.value === value);
  const displayLabel = selected?.label ?? value ?? '';

  return (
    <div ref={ref} className={`relative ${className}`}>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setOpen(!open); } }}
        aria-haspopup="listbox"
        aria-expanded={open}
        className={`
          flex items-center gap-1 cursor-pointer transition-all duration-200 outline-none w-29 p-2.5

          ${size === 'sm'
            ? 'text-xs rounded-lg shadow-sm'
            : 'text-sm rounded-xl shadow-sm'
          }
          border border-gray-200 bg-white hover:border-gray-300 hover:shadow
          focus:border-primary-400 focus:ring-2 focus:ring-primary-500/20
        `}
      >
        <span className="flex-1 truncate">{displayLabel}</span>
        <ChevronDown
          size={size === 'sm' ? 12 : 15}
          className={`text-gray-400 transition-transform duration-200 shrink-0 ${open ? 'rotate-180' : ''}`}
        />
      </button>

      {open && (
        <div
          className={`
            absolute z-50 mt-1 bg-white border border-gray-200 rounded-xl shadow-lg overflow-hidden
            ${size === 'sm' ? 'w-29' : 'w-29'}
            right-0
          `}
          role="listbox"
        >
          {items.map((item, i) => (
            <button
              key={item.value}
              type="button"
              role="option"
              aria-selected={item.value === value}
              onClick={() => { onChange(item.value); setOpen(false); }}
              className={`
                w-full px-3 py-2 text-sm transition-colors
                ${item.value === value
                  ? 'bg-primary-50 text-primary-700 font-medium'
                  : 'text-gray-700 hover:bg-gray-50'
                }
                ${i < items.length - 1 ? 'border-b border-gray-100' : ''}
              `}
            >
              {item.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
