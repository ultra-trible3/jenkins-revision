import { useEffect, useRef } from 'react';

export default function ConfirmationDialog({ open, title, message, onConfirm, onCancel, confirmText = 'تأكيد', cancelText = 'إلغاء', variant = 'danger' }) {
  const dialogRef = useRef(null);

  useEffect(() => {
    if (open && dialogRef.current) {
      dialogRef.current.showModal();
    } else if (dialogRef.current) {
      dialogRef.current.close();
    }
  }, [open]);

  const confirmColors = variant === 'danger'
    ? 'bg-red-600 hover:bg-red-700'
    : 'bg-primary-600 hover:bg-primary-700';

  return (
    <dialog ref={dialogRef} className="rounded-lg shadow-xl border-0 p-0 backdrop:bg-black/50 max-w-md w-full absolute top-2/5 right-2/5" onClose={onCancel}>
      <div className="p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-2">{title}</h3>
        <p className="text-gray-600 mb-6">{message}</p>
        <div className="flex gap-3 justify-end">
          <button onClick={onCancel} className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors">
            {cancelText}
          </button>
          <button onClick={onConfirm} className={`px-4 py-2 text-sm font-medium text-white rounded-lg transition-colors ${confirmColors}`}>
            {confirmText}
          </button>
        </div>
      </div>
    </dialog>
  );
}
