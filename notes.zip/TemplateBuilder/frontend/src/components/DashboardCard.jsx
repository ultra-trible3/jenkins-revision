export default function DashboardCard({ title, value, icon: Icon, gradient = 'from-primary-500 to-primary-600', iconBg = 'bg-primary-100 text-primary-600', subtitle, onClick }) {
  return (
    <div
      onClick={onClick}
      className={`relative overflow-hidden rounded-2xl p-6 transition-all duration-300 ${onClick ? 'cursor-pointer hover:shadow-xl hover:-translate-y-1' : ''} bg-white border border-gray-100 shadow-sm group`}
    >
      <div className={`absolute top-0 right-0 left-0 h-1 bg-linear-to-r ${gradient}`} />
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-500">{title}</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">{value}</p>
          {subtitle && <p className="text-sm text-gray-500 mt-1">{subtitle}</p>}
        </div>
        <div className={`p-3.5 rounded-2xl ${iconBg} group-hover:scale-110 transition-transform duration-300`}>
          <Icon size={26} />
        </div>
      </div>
    </div>
  );
}
