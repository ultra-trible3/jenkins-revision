export const UNIFIED_FIELDS = [
  { key: 'date', label: 'تاريخ الممارسة', type: 'date' },
  { key: 'date2', label: 'تاريخ المذكرة', type: 'date' },
  { key: 'day_input', label: 'يوم انعقاد اللجنة', type: 'select', options: ['الاحد', 'الاثنين', 'الثلاثاء', 'الاربعاء', 'الخميس', 'الجمعة', 'السبت'] },
  { key: 'input_hour', label: 'وقت انعقاد اللجنة', type: 'text' },
  // { key: 'isOneOffer', label: 'عرض واحد', type: 'checkbox' },

  { key: 'input_description', label: 'الشـــــأن', type: 'text' },
  { key: 'input_year', label: 'العام المالي', type: 'text' },
  { key: 'input_text_area', label: 'رأي اللجنة', type: 'textarea' },

  { key: 'input_budget', label: 'المبلغ المخصص', type: 'number' },
  { key: 'full_budget', label: 'المبلغ الاجمالى', type: 'number' },
  { key: 'input3_budget_s', label: 'السعر المبدئى للشركة الأولى', type: 'number' },
  { key: 'input3_budget_f', label: 'السعر النهائى للشركة الأولى', type: 'number' },
  { key: 'input4_budget_s', label: 'السعر المبدئى للشركة الثانية', type: 'number' },
  { key: 'input4_budget_f', label: 'السعر النهائى للشركة الثانية', type: 'number' },
  { key: 'input5_budget_s', label: 'السعر المبدئى للشركة الثالثة', type: 'number' },
  { key: 'input5_budget_f', label: 'السعر النهائى للشركة الثالثة', type: 'number' },
  { key: 'input6_budget_s', label: 'السعر المبدئى للشركة الرابعة', type: 'number' },
  { key: 'input6_budget_f', label: 'السعر النهائى للشركة الرابعة', type: 'number' },
  { key: 'input7_budget_s', label: 'السعر المبدئى للشركة الخامسة', type: 'number' },
  { key: 'input7_budget_f', label: 'السعر النهائى للشركة الخامسة', type: 'number' },
  { key: 'final_budget', label: 'السعر النهائي', type: 'number' },
  // { key: 'input_percentage',        label: 'النسبة المئوية من الشركة', type: 'range', min: 0, max: 100 },
  { key: 'percentage_page1', label: 'النسبة المئوية من الشركة', type: 'number', min: 0, max: 100 },
  { key: 'currency', label: 'العملة', type: 'select', options: ['دولار', 'جنية مصرى', 'يورو', 'جنية استرلينى'] },
  { key: 'training', label: 'التدريـــــــــــــــــب', type: 'checkbox' },
  { key: 'training_value', label: 'تفاصيل التدريب', type: 'text' },

  { key: 'Authority', label: 'الجهة الوارد منها', type: 'text' },
  { key: 'company1', label: 'الشركة الأولى', type: 'text' },
  { key: 'company2', label: 'الشركة الثانية', type: 'text' },
  { key: 'company3', label: 'الشركة الثالثة', type: 'text' },
  { key: 'company4', label: 'الشركة الرابعة', type: 'text' },
  { key: 'company5', label: 'الشركة الخامسة', type: 'text' },

  { key: 'category', label: 'رقم مذكرة العرض', type: 'text' },
  { key: 'list_member[0]', label: 'رئيس اللجنة', type: 'text' },
  { key: 'list_member[1]', label: 'عضو مالي', type: 'text' },
  { key: 'list_member[2]', label: 'عضو الشركة', type: 'text' },
  { key: 'list_member[3]', label: 'عضو فني', type: 'text' },
];

export const PAGE1_ORDER = [
  'date',
  'input_description',
  'category',
  'date2',
  'input_budget',
  'currency',
  'full_budget',
  'input_year',
  'Authority',
  'list_member[0]',
  'list_member[1]',
  'list_member[2]',
  'list_member[3]',
  'input_hour',
  'day_input',
  // 'isOneOffer',
  'company1',
  'input3_budget_s',
  'company2',
  'input4_budget_s',
  'company3',
  'input5_budget_s',
  'company4',
  'input6_budget_s',
  'company5',
  'input7_budget_s',
  'percentage_page1',
  'final_budget',
];

export const PAGE2_ORDER = [
  'input_text_area',
];

export const SUMMARY_ORDER = [
  'date',
  'input_description',
  'currency',
  'company1',
  'company2',
  'company3',
  'input3_budget_s',
  'input4_budget_s',
  'input5_budget_s',
  'input6_budget_s',
  'input7_budget_s',
  'input3_budget_f',
  'input4_budget_f',
  'input5_budget_f',
  'input6_budget_f',
  'input7_budget_f',
  'training_value',
];

export const TEMPLATE_CONFIGS = {
  committee: {
    label: 'لجان',
    pages: [
      {
        title: 'الصفحة الأولى',
        keys: PAGE1_ORDER,
        memberKeys: ['list_member[0]', 'list_member[1]', 'list_member[2]', 'list_member[3]'],
        icon: 'FileText',
        color: 'bg-blue-50/60',
        border: 'border-blue-200/60',
        header: 'text-blue-800',
        iconBg: 'bg-blue-100 text-blue-600',
      },
      {
        title: 'الصفحة الثانية',
        keys: PAGE2_ORDER,
        icon: 'FileText',
        color: 'bg-green-50/60',
        border: 'border-green-200/60',
        header: 'text-green-800',
        iconBg: 'bg-green-100 text-green-600',
      },
    ],
  },
  summary: {
    label: 'بيانات الكشــف التفريغــى',
    pages: [
      {
        title: 'بيانات الكشــف التفريغــى',
        keys: SUMMARY_ORDER,
        memberKeys: ['list_member[0]', 'list_member[1]', 'list_member[2]', 'list_member[3]'],
        icon: 'FileText',
        color: 'bg-blue-50/60',
        border: 'border-blue-200/60',
        header: 'text-blue-800',
        iconBg: 'bg-blue-100 text-blue-600',
      }
    ],
  },
};

export function getFieldConfig(key) {
  return UNIFIED_FIELDS.find((f) => f.key === key) || null;
}

export function normalizeKey(key) {
  return key.replace(/\s+/g, '');
}

export const KEY_ALIASES = {
  'drop_downlist': 'category',
  'drop_down_list_currency': 'currency',
  'input2_budget': 'full_budget',
  'input': 'input_year',
  'drop_down_list_member[0]': 'list_member[0]',
  'drop_down_list_ member[0]': 'list_member[0]',
  'drop_down_list_ member[1]': 'list_member[1]',
  'drop_down_list_ member[2]': 'list_member[2]',
  'drop_down_list_ member[3]': 'list_member[3]',
  'drop_down_list_member[1]': 'list_member[1]',
  'drop_down_list_member[2]': 'list_member[2]',
  'drop_down_list_member[3]': 'list_member[3]',
  'input_percentage_page1': 'percentage_page1',
  'input_percentage[0:100]': 'input_percentage_page1',
  'comapny2': 'company2',
};

export function normalizeFormData(data) {
  const result = { ...data };
  const reversed = {};
  for (const [oldKey, newKey] of Object.entries(KEY_ALIASES)) {
    if (result[oldKey] !== undefined && result[newKey] === undefined) {
      result[newKey] = result[oldKey];
    }
  }
  return result;
}
