import { useState, useEffect } from 'react';
import { contractService } from '../services/contractService';
import LoadingSpinner from '../components/LoadingSpinner';
import { Users, Plus, Trash2, Pencil, Save, X } from 'lucide-react';
import { useToast } from '../hooks/useToast';

const ROLE_OPTIONS = [
  { value: 'chair', label: 'رئيس اللجنة' },
  { value: 'financial', label: 'عضو مالي' },
  { value: 'company', label: 'عضو الشركة' },
  { value: 'technical', label: 'عضو فني' },
];

const ROLE_COLORS = {
  chair: 'bg-purple-50 text-purple-700',
  financial: 'bg-blue-50 text-blue-700',
  company: 'bg-green-50 text-green-700',
  technical: 'bg-orange-50 text-orange-700',
};

export default function Members() {
  const toast = useToast();
  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState('chair');
  const [adding, setAdding] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editName, setEditName] = useState('');
  const [editRole, setEditRole] = useState('');

  const fetchMembers = async () => {
    setLoading(true);
    try {
      const { data } = await contractService.listMembers();
      setMembers(data.results || data);
    } catch {
      toast.error('فشل تحميل أعضاء اللجنة');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMembers();
  }, []);

  const handleAdd = async (e) => {
    e.preventDefault();
    const trimmed = newName.trim();
    if (!trimmed) return;
    setAdding(true);
    try {
      await contractService.createMember({ name: trimmed, role: newRole });
      setNewName('');
      toast.success('تمت إضافة العضو');
      fetchMembers();
    } catch {
      toast.error('فشل إضافة العضو');
    } finally {
      setAdding(false);
    }
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`هل أنت متأكد من حذف "${name}"؟`)) return;
    try {
      await contractService.deleteMember(id);
      toast.success('تم حذف العضو');
      fetchMembers();
    } catch {
      toast.error('فشل حذف العضو');
    }
  };

  const startEdit = (id, name, role) => {
    setEditingId(id);
    setEditName(name);
    setEditRole(role);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditName('');
    setEditRole('');
  };

  const handleUpdate = async (id) => {
    const trimmed = editName.trim();
    if (!trimmed) return;
    try {
      await contractService.updateMember(id, { name: trimmed, role: editRole });
      toast.success('تم تحديث العضو');
      setEditingId(null);
      setEditName('');
      setEditRole('');
      fetchMembers();
    } catch {
      toast.error('فشل تحديث العضو');
    }
  };

  const inputClass = "w-full px-4 py-2.5 border border-gray-200 rounded-xl outline-none text-sm focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 bg-white";

  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <Users size={24} className="text-primary-600" />
        <h1 className="text-2xl font-bold text-gray-900">أعضاء اللجنة</h1>
      </div>

      <form onSubmit={handleAdd} className="bg-white rounded-xl border border-gray-200 p-4 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <div className="md:col-span-2">
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">اسم العضو</label>
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="أدخل اسم العضو..."
              className={inputClass}
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">الدور</label>
            <select
              value={newRole}
              onChange={(e) => setNewRole(e.target.value)}
              className={inputClass}
            >
              {ROLE_OPTIONS.map((r) => (
                <option key={r.value} value={r.value}>{r.label}</option>
              ))}
            </select>
          </div>
          <div className="flex items-end">
            <button
              type="submit"
              disabled={adding || !newName.trim()}
              className="flex items-center gap-2 bg-primary-600 text-white px-5 py-2.5 rounded-xl hover:bg-primary-700 transition-colors text-sm font-medium w-full justify-center disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Plus size={16} />
              {adding ? 'جاري الإضافة...' : 'إضافة'}
            </button>
          </div>
        </div>
      </form>

      {loading ? (
        <LoadingSpinner />
      ) : members.length === 0 ? (
        <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
          <Users size={48} className="mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500">لا يوجد أعضاء مسجلين</p>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="text-right px-6 py-3 text-sm font-semibold text-gray-700">#</th>
                <th className="text-right px-6 py-3 text-sm font-semibold text-gray-700">اسم العضو</th>
                <th className="text-right px-6 py-3 text-sm font-semibold text-gray-700">الدور</th>
                <th className="text-right px-6 py-3 text-sm font-semibold text-gray-700">الحالة</th>
                <th className="text-center px-6 py-3 text-sm font-semibold text-gray-700">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {members.map((member, index) => (
                <tr key={member.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 text-sm text-gray-500">{index + 1}</td>
                  <td className="px-6 py-4">
                    {editingId === member.id ? (
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="flex-1 px-3 py-1.5 border border-gray-200 rounded-lg outline-none text-sm focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500"
                          autoFocus
                        />
                        <select
                          value={editRole}
                          onChange={(e) => setEditRole(e.target.value)}
                          className="px-3 py-1.5 border border-gray-200 rounded-lg outline-none text-sm focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500"
                        >
                          {ROLE_OPTIONS.map((r) => (
                            <option key={r.value} value={r.value}>{r.label}</option>
                          ))}
                        </select>
                        <button onClick={() => handleUpdate(member.id)} className="p-1.5 text-green-600 hover:bg-green-50 rounded-lg" title="حفظ">
                          <Save size={16} />
                        </button>
                        <button onClick={cancelEdit} className="p-1.5 text-gray-500 hover:bg-gray-100 rounded-lg" title="إلغاء">
                          <X size={16} />
                        </button>
                      </div>
                    ) : (
                      <span className="text-sm font-medium text-gray-900">{member.name}</span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${ROLE_COLORS[member.role] || 'bg-gray-50 text-gray-700'}`}>
                      {member.role_display}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${member.is_active ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
                      {member.is_active ? 'نشط' : 'غير نشط'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    {editingId !== member.id && (
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => startEdit(member.id, member.name, member.role)}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="تعديل"
                        >
                          <Pencil size={16} />
                        </button>
                        <button
                          onClick={() => handleDelete(member.id, member.name)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="حذف"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
