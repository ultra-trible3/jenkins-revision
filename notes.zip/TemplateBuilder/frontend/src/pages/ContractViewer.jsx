import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { contractService } from '../services/contractService';
import LoadingSpinner from '../components/LoadingSpinner';
import { useToast } from '../hooks/useToast';
import { downloadFile } from '../utils/helpers';
import { ArrowRight, ExternalLink, FileText, Pencil, Save, Hash, Paperclip, Download, Trash2, X } from 'lucide-react';
import CustomSelect from '../components/CustomSelect';

const COMPANY_GROUPS = [
  { company: 'company1', budgetS: 'input3_budget_s', budgetF: 'input3_budget_f' },
  { company: 'company2', budgetS: 'input4_budget_s', budgetF: 'input4_budget_f' },
  { company: 'company3', budgetS: 'input5_budget_s', budgetF: 'input5_budget_f' },
  { company: 'company4', budgetS: 'input6_budget_s', budgetF: 'input6_budget_f' },
  { company: 'company5', budgetS: 'input7_budget_s', budgetF: 'input7_budget_f' },
];


const _ONE_OFFER_TARGETS = [
  'company2','company3','company4','company5',
  'input4_budget_s','input5_budget_s','input6_budget_s','input7_budget_s',
  'input4_budget_f','input5_budget_f','input6_budget_f','input7_budget_f',
];

export default function ContractViewer() {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const toast = useToast();
  const previewRef = useRef(null);
  const injectGenRef = useRef(0);
  const [contract, setContract] = useState(null);
  const [previewHtml, setPreviewHtml] = useState('');
  const [template, setTemplate] = useState('committee');
  const [loading, setLoading] = useState(true);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editMode, setEditMode] = useState(searchParams.get('quickEdit') === 'true');
  const [attachments, setAttachments] = useState([]);
  const [showAttachments, setShowAttachments] = useState(false);
  const [viewerFile, setViewerFile] = useState(null);

  const fetchPreview = useCallback(async (mode) => {
    if (!contract) return;
    setPreviewLoading(true);
    try {
      const { data } = await contractService.preview(id, template, mode);
      setPreviewHtml(data.html);
    } catch {
      setPreviewHtml('<p style="color:red;text-align:center;padding:40px">Failed to load preview</p>');
    } finally {
      setPreviewLoading(false);
    }
  }, [id, template, contract]);

  useEffect(() => {
    contractService.get(id)
      .then(({ data }) => {
        setContract(data);
        setTemplate(data.template_name || 'committee');
        contractService.listAttachments(id)
          .then(({ data: attData }) => setAttachments(attData.results || attData))
          .catch(() => {});
      })
      .catch(() => { toast.error('Failed to load contract'); navigate('/contracts'); })
      .finally(() => setLoading(false));
  }, [id, navigate, toast]);

  useEffect(() => {
    if (!contract) return;
    fetchPreview(editMode ? 'edit' : '');
  }, [fetchPreview, editMode]);

  useEffect(() => {
    if (searchParams.get('print') === 'true' && previewHtml) {
      setTimeout(() => window.print(), 500);
    }
  }, [searchParams, previewHtml]);

  useEffect(() => {
    const root = previewRef.current;
    if (!root) return;

    function applyOneOffer(checked) {
      root.querySelectorAll("input[data-var]").forEach(other => {
        if (_ONE_OFFER_TARGETS.includes(other.dataset.var)) {
          other.disabled = checked;
        }
      });
    }

    function syncInputs(e) {
      const input = e.target;
      if (!(input instanceof HTMLInputElement)) return;

      const key = input.dataset.var;
      if (!key) return;

      if (input.type === 'checkbox') {
        root.querySelectorAll("input[data-var]").forEach(other => {
          if (other === input) return;
          if (other.dataset.var === key) other.checked = input.checked;
        });
        if (key === 'isOneOffer') {
          applyOneOffer(input.checked);
        }
        return;
      }

      root.querySelectorAll("input[data-var]").forEach(other => {
        if (other === input) return;
        if (other.dataset.var === key) {
          other.value = input.value;
        }
      });
    }

    root.addEventListener("input", syncInputs);

    const oneOfferCheck = root.querySelector('input[data-var="isOneOffer"]');
    if (oneOfferCheck) applyOneOffer(oneOfferCheck.checked);

    const mo = new MutationObserver(() => {});
    mo.observe(root, { childList: true, subtree: true, attributes: true, characterData: true });

    if (editMode && template === 'committee') {
      injectGenRef.current += 1;
      injectCompanyButtons(root, injectGenRef.current);
    }

    return () => {
      root.removeEventListener("input", syncInputs);
      mo.disconnect();
      root.querySelectorAll('[id^="company-"]').forEach(el => el.remove());
    };
  }, [previewHtml, editMode, template]);

  function injectCompanyButtons(root, gen) {
    const AR_LETTERS = ['أ', 'ب', 'ج', 'د', 'ه'];
    const liveRoot = () => previewRef.current;

    function cleanText(s) {
      return s.replace(/[\u200B-\u200F\u2028-\u202F\u2060-\u2069\uFEFF]/g, '').trim();
    }

    function updateLabels(container, number, letter) {
      const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, null, false);
      while (walker.nextNode()) {
        const node = walker.currentNode;
        const cleaned = cleanText(node.textContent);
        if (/^[أبجده]\s*[-–—](?!\d)/.test(cleaned)) {
          node.textContent = node.textContent.replace(/^[\s\u200B-\u200F\u2028-\u202F\u2060-\u2069\uFEFF]*[أبجده]/, letter);
          continue;
        }
        if (/^\d+\s*[-–—](?!\d)/.test(cleaned)) {
          node.textContent = node.textContent.replace(/^[\s\u200B-\u200F\u2028-\u202F\u2060-\u2069\uFEFF]*\d+/, String(number));
        }
      }
    }
    function getNextIndex() {
      for (let i = 1; i < 5; i++) {
        const inp = root.querySelector(`input[data-var="${COMPANY_GROUPS[i].company}"]`);
        if (!inp || inp.parentElement?.style?.display === 'none') return i;
      }
      return -1;
    }

    function makeBtn(text, title, color, bg) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = text;
      btn.title = title;
      btn.style.cssText = `display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;border-radius:50%;border:2px solid ${color};cursor:pointer;font-size:16px;font-weight:bold;line-height:1;color:${color};background:${bg};margin:0 4px;vertical-align:middle;`;
      return btn;
    }

    function findLastInput(fieldKey) {
      for (let i = 4; i >= 0; i--) {
        const inp = root.querySelector(`input[data-var="${COMPANY_GROUPS[i][fieldKey]}"]`);
        if (inp && inp.parentElement?.style?.display !== 'none') return inp;
      }
      return null;
    }

    function removeCompany(index) {
      const g = COMPANY_GROUPS[index];
      const nameInp = root.querySelector(`input[data-var="${g.company}"]`);
      if (nameInp?.parentElement) nameInp.parentElement.style.display = 'none';
      const budgetS = root.querySelector(`input[data-var="${g.budgetS}"]`);
      if (budgetS?.parentElement) budgetS.parentElement.style.display = 'none';
      const budgetF = root.querySelector(`input[data-var="${g.budgetF}"]`);
      if (budgetF?.parentElement) budgetF.parentElement.style.display = 'none';
      if (nameInp) nameInp.dataset.hidden = '1';

      // Renumber remaining visible companies
      let n = 1;
      for (let i = 0; i < 5; i++) {
        const g = COMPANY_GROUPS[i];
        const inp = root.querySelector(`input[data-var="${g.company}"]`);
        if (!inp || inp.parentElement?.style?.display === 'none') continue;
        updateLabels(inp.parentElement, n, AR_LETTERS[n - 1] || 'أ');
        const budgetF = root.querySelector(`input[data-var="${g.budgetF}"]`);
        if (budgetF?.parentElement && budgetF.parentElement !== inp.parentElement) {
          updateLabels(budgetF.parentElement, n, AR_LETTERS[n - 1] || 'أ');
        }
        n++;
      }

      const plusBtn = root.querySelector('#company-plus-btn');
      if (plusBtn) plusBtn.style.display = '';
    }

    function cloneCompany1As(index) {
      const c1 = COMPANY_GROUPS[0];
      const target = COMPANY_GROUPS[index];
      const nameInp = root.querySelector(`input[data-var="${c1.company}"]`);
      const budgetSInp = root.querySelector(`input[data-var="${c1.budgetS}"]`);
      const budgetFInp = root.querySelector(`input[data-var="${c1.budgetF}"]`);

      const keyMap = {
        [c1.company]: target.company,
        [c1.budgetS]: target.budgetS,
        [c1.budgetF]: target.budgetF,
      };

      function cloneParent(parentEl) {
        if (!parentEl) return null;
        const clone = parentEl.cloneNode(true);
        clone.querySelectorAll('input[data-var]').forEach(inp => {
          const oldKey = inp.dataset.var;
          if (keyMap[oldKey]) {
            inp.dataset.var = keyMap[oldKey];
            inp.value = '';
            if (inp.name) inp.name = inp.name.replace(oldKey, keyMap[oldKey]);
            if (inp.id) inp.id = inp.id.replace(oldKey, keyMap[oldKey]);
          }
        });
        return clone;
      }

      const np = nameInp?.parentElement;
      const bpS = budgetSInp?.parentElement;
      const bpF = budgetFInp?.parentElement;

      return {
        nameClone: cloneParent(np),
        budgetSClone: bpS !== np ? cloneParent(bpS) : null,
        budgetFClone: bpF !== np && bpF !== bpS ? cloneParent(bpF) : null,
      };
    }

    function addCompany() {
      const idx = getNextIndex();
      if (idx === -1) return;

      // Count visible companies for label numbering
      let companyCount = 0;
      for (let i = 0; i < 5; i++) {
        const inp = root.querySelector(`input[data-var="${COMPANY_GROUPS[i].company}"]`);
        if (inp && inp.parentElement?.style?.display !== 'none') companyCount++;
      }

      // Remove stale hidden elements for this company
      const g = COMPANY_GROUPS[idx];
      [g.company, g.budgetS, g.budgetF].forEach(key => {
        const inp = root.querySelector(`input[data-var="${key}"]`);
        if (inp && inp.parentElement?.style?.display === 'none') inp.parentElement.remove();
      });
      root.querySelector(`#company-minus-${idx}`)?.remove();

      const { nameClone, budgetSClone, budgetFClone } = cloneCompany1As(idx);
      if (!nameClone) return;

      // Update labels in all clones
      const newNum = companyCount + 1;
      const letter = AR_LETTERS[newNum - 1] || 'أ';
      updateLabels(nameClone, newNum, letter);
      if (budgetSClone) updateLabels(budgetSClone, newNum, letter);
      if (budgetFClone) updateLabels(budgetFClone, newNum, letter);

      const lastName = findLastInput('company');
      const lastBudgetS = findLastInput('budgetS');
      const lastBudgetF = findLastInput('budgetF');

      if (nameClone && lastName?.parentElement) {
        nameClone.style.display = 'block';
        lastName.parentElement.parentNode.insertBefore(nameClone, lastName.parentElement.nextSibling);
      }
      if (budgetSClone && lastBudgetS?.parentElement) {
        budgetSClone.style.display = 'block';
        lastBudgetS.parentElement.parentNode.insertBefore(budgetSClone, lastBudgetS.parentElement.nextSibling);
      }
      if (budgetFClone && lastBudgetF?.parentElement) {
        budgetFClone.style.display = 'block';
        lastBudgetF.parentElement.parentNode.insertBefore(budgetFClone, lastBudgetF.parentElement.nextSibling);
      }

      addMinusBtn(idx);
      const plusBtn = root.querySelector('#company-plus-btn');
      if (getNextIndex() === -1 && plusBtn) plusBtn.style.display = 'none';
    }

    function addMinusBtn(index) {
      if (index === 0) return;
      if (root.querySelector(`#company-minus-${index}`)) return;
      const nameInp = root.querySelector(`input[data-var="${COMPANY_GROUPS[index].company}"]`);
      if (!nameInp) return;
      const btn = makeBtn('−', 'حذف الشركة', '#dc2626', '#fef2f2');
      btn.id = `company-minus-${index}`;
      btn.onclick = () => removeCompany(index);
      nameInp.parentNode.insertBefore(btn, nameInp.parentNode.childNodes[0]);
    }

    // Add (−) buttons for existing companies 2-5
    for (let i = 1; i < 5; i++) {
      const nameInp = root.querySelector(`input[data-var="${COMPANY_GROUPS[i].company}"]`);
      if (nameInp) {
        if (!root.querySelector(`#company-minus-${i}`)) addMinusBtn(i);
      }
    }

    // Add (+) button on its own line after last existing company's paragraph
    const lastNameInp = findLastInput('company');
    if (lastNameInp?.parentElement && !root.querySelector('#company-plus-btn')) {
      const plusBtn = makeBtn('+', 'إضافة شركة', '#b45309', '#fef3c7');
      plusBtn.id = 'company-plus-btn';
      plusBtn.onclick = addCompany;
      const container = document.createElement('div');
      container.style.cssText = 'display:flex;justify-content:center;margin:12px 0;';
      container.appendChild(plusBtn);
      lastNameInp.parentElement.parentNode.insertBefore(container, lastNameInp.parentElement.nextSibling);
    }

    // Hide (+) if already at max companies
    if (getNextIndex() === -1) {
      const btn = root.querySelector('#company-plus-btn');
      if (btn) btn.style.display = 'none';
    }

    // Create inputs for companies that exist in form_data but not in the DOM
    const fd = contract?.form_data;
    for (let i = 1; i < 5; i++) {
      if (root.querySelector(`input[data-var="${COMPANY_GROUPS[i].company}"]`)) continue;
      if (!fd?.[COMPANY_GROUPS[i].company]) continue;

      const { nameClone, budgetSClone, budgetFClone } = cloneCompany1As(i);
      if (!nameClone) continue;

      nameClone.querySelector('input[data-var]').value = fd[COMPANY_GROUPS[i].company] || '';
      if (budgetSClone) budgetSClone.querySelector('input[data-var]').value = fd[COMPANY_GROUPS[i].budgetS] || '';
      if (budgetFClone) budgetFClone.querySelector('input[data-var]').value = fd[COMPANY_GROUPS[i].budgetF] || '';

      // Update labels in all clones
      const letter = AR_LETTERS[i] || 'أ';
      updateLabels(nameClone, i + 1, letter);
      if (budgetSClone) updateLabels(budgetSClone, i + 1, letter);
      if (budgetFClone) updateLabels(budgetFClone, i + 1, letter);

      const lastName = findLastInput('company');
      const lastBudgetS = findLastInput('budgetS');
      const lastBudgetF = findLastInput('budgetF');

      if (lastName?.parentElement) {
        nameClone.style.display = 'block';
        lastName.parentElement.parentNode.insertBefore(nameClone, lastName.parentElement.nextSibling);
      }
      if (budgetSClone && lastBudgetS?.parentElement) {
        budgetSClone.style.display = 'block';
        lastBudgetS.parentElement.parentNode.insertBefore(budgetSClone, lastBudgetS.parentElement.nextSibling);
      }
      if (budgetFClone && lastBudgetF?.parentElement) {
        budgetFClone.style.display = 'block';
        lastBudgetF.parentElement.parentNode.insertBefore(budgetFClone, lastBudgetF.parentElement.nextSibling);
      }

      addMinusBtn(i);
    }

    // Restore hidden state from saved data
    const hidden = contract?.form_data?._hidden_companies;
    if (hidden) {
      hidden.forEach(idx => {
        const g = COMPANY_GROUPS[idx];
        const nameInp = root.querySelector(`input[data-var="${g.company}"]`);
        if (nameInp?.parentElement) nameInp.parentElement.style.display = 'none';
        const budgetS = root.querySelector(`input[data-var="${g.budgetS}"]`);
        if (budgetS?.parentElement) budgetS.parentElement.style.display = 'none';
        const budgetF = root.querySelector(`input[data-var="${g.budgetF}"]`);
        if (budgetF?.parentElement) budgetF.parentElement.style.display = 'none';
        if (nameInp) nameInp.dataset.hidden = '1';
      });
    }

    // Replace company name inputs with dropdown selects
    contractService.listCompanies()
      .then(({ data }) => {
        if (gen !== injectGenRef.current) return;
        const dom = liveRoot();
        if (!dom || !dom.isConnected) return;
        const companiesList = data.results || data;
        COMPANY_GROUPS.forEach(g => {
          const inp = dom.querySelector(`input[data-var="${g.company}"]`);
          if (!inp || inp.dataset.dropdown === '1') return;

          const currentValue = inp.value || '';
          const select = document.createElement('select');
          select.dataset.var = g.company;
          select.dataset.dropdown = '1';
          select.style.cssText = 'width:100%;padding:6px 10px;border:2px dashed #cb0101;border-radius:8px;background:transparent;color:#cb0101;font-weight:600;text-align:center;font-family:inherit;font-size:inherit;outline:none;cursor:pointer;';

          const placeholder = document.createElement('option');
          placeholder.value = '';
          placeholder.textContent = 'اختر شركة...';
          select.appendChild(placeholder);

          companiesList.forEach(c => {
            const opt = document.createElement('option');
            opt.value = c.name;
            opt.textContent = c.name;
            if (c.name === currentValue) opt.selected = true;
            select.appendChild(opt);
          });

          if (currentValue && !companiesList.some(c => c.name === currentValue)) {
            const opt = document.createElement('option');
            opt.value = currentValue;
            opt.textContent = currentValue;
            opt.selected = true;
            select.appendChild(opt);
          }

          const manualOpt = document.createElement('option');
          manualOpt.value = '__manual__';
          manualOpt.textContent = '+ إدخال يدوي';
          select.appendChild(manualOpt);

          inp.style.display = 'none';
          inp.parentNode.insertBefore(select, inp.nextSibling);

          select.addEventListener('change', () => {
            if (select.value === '__manual__') {
              select.style.display = 'none';
              inp.style.display = '';
              inp.value = inp.value || '';
              inp.focus();
            } else {
              inp.value = select.value;
            }
          });

          inp.addEventListener('input', () => {
            if (inp.style.display !== 'none') {
              const matchingOpt = Array.from(select.options).find(o => o.value === inp.value);
              if (!matchingOpt) {
                const opt = document.createElement('option');
                opt.value = inp.value;
                opt.textContent = inp.value;
                select.insertBefore(opt, manualOpt);
              }
              select.value = inp.value;
            }
          });
        });
      })
      .catch((err) => {
        console.error('[injectCompanyButtons] listCompanies failed:', err);
        toast.error('فشل تحميل قائمة الشركات');
      });

    // Replace member name inputs with dropdown selects
    const MEMBER_KEYS = ['list_member[0]', 'list_member[1]', 'list_member[2]', 'list_member[3]'];
    const MEMBER_ROLE_MAP = {
      'list_member[0]': 'chair',
      'list_member[1]': 'financial',
      'list_member[2]': 'company',
      'list_member[3]': 'technical',
    };
    contractService.listMembers()
      .then(({ data }) => {
        if (gen !== injectGenRef.current) return;
        const dom = liveRoot();
        if (!dom || !dom.isConnected) return;
        const membersList = data.results || data;
        MEMBER_KEYS.forEach(key => {
          const inp = dom.querySelector(`input[data-var="${key}"]`);
          if (!inp || inp.dataset.dropdown === '1') return;

          const role = MEMBER_ROLE_MAP[key];
          const filteredMembers = membersList.filter(m => m.role === role);
          const currentValue = inp.value || '';
          const select = document.createElement('select');
          select.dataset.var = key;
          select.dataset.dropdown = '1';
          select.style.cssText = 'width:100%;padding:6px 10px;border:2px dashed #2563eb;border-radius:8px;background:transparent;color:#2563eb;font-weight:600;text-align:center;font-family:inherit;font-size:inherit;outline:none;cursor:pointer;';

          const placeholder = document.createElement('option');
          placeholder.value = '';
          placeholder.textContent = 'اختر عضو...';
          select.appendChild(placeholder);

          filteredMembers.forEach(m => {
            const opt = document.createElement('option');
            opt.value = m.name;
            opt.textContent = m.name;
            if (m.name === currentValue) opt.selected = true;
            select.appendChild(opt);
          });

          if (currentValue && !filteredMembers.some(m => m.name === currentValue)) {
            const opt = document.createElement('option');
            opt.value = currentValue;
            opt.textContent = currentValue;
            opt.selected = true;
            select.appendChild(opt);
          }

          const manualOpt = document.createElement('option');
          manualOpt.value = '__manual__';
          manualOpt.textContent = '+ إدخال يدوي';
          select.appendChild(manualOpt);

          inp.style.display = 'none';
          inp.parentNode.insertBefore(select, inp.nextSibling);

          select.addEventListener('change', () => {
            if (select.value === '__manual__') {
              select.style.display = 'none';
              inp.style.display = '';
              inp.value = inp.value || '';
              inp.focus();
            } else {
              inp.value = select.value;
            }
          });

          inp.addEventListener('input', () => {
            if (inp.style.display !== 'none') {
              const matchingOpt = Array.from(select.options).find(o => o.value === inp.value);
              if (!matchingOpt) {
                const opt = document.createElement('option');
                opt.value = inp.value;
                opt.textContent = inp.value;
                select.insertBefore(opt, manualOpt);
              }
              select.value = inp.value;
            }
          });
        });
      })
      .catch((err) => {
        console.error('[injectCompanyButtons] listMembers failed:', err);
        toast.error('فشل تحميل قائمة الأعضاء');
      });

    // Replace input_text_area with entity dropdown
    contractService.listEntities()
      .then(({ data }) => {
        if (gen !== injectGenRef.current) return;
        const dom = liveRoot();
        if (!dom || !dom.isConnected) return;
        const entitiesList = data.results || data;
        const inp = dom.querySelector('input[data-var="input_text_area"]');
        if (!inp || inp.dataset.dropdown === '1') return;

        const currentValue = inp.value || '';
        const select = document.createElement('select');
        select.dataset.var = 'input_text_area';
        select.dataset.dropdown = '1';
        select.style.cssText = 'width:100%;padding:6px 10px;border:2px dashed #10b981;border-radius:8px;background:transparent;color:#10b981;font-weight:600;text-align:center;font-family:inherit;font-size:inherit;outline:none;cursor:pointer;';

        const placeholder = document.createElement('option');
        placeholder.value = '';
        placeholder.textContent = 'اختر الجهة...';
        select.appendChild(placeholder);

        entitiesList.forEach(e => {
          const opt = document.createElement('option');
          opt.value = e.name;
          opt.textContent = e.name;
          if (e.name === currentValue) opt.selected = true;
          select.appendChild(opt);
        });

        if (currentValue && !entitiesList.some(e => e.name === currentValue)) {
          const opt = document.createElement('option');
          opt.value = currentValue;
          opt.textContent = currentValue;
          opt.selected = true;
          select.appendChild(opt);
        }

        inp.style.display = 'none';
        inp.parentNode.insertBefore(select, inp.nextSibling);

        select.addEventListener('change', () => {
          inp.value = select.value;
        });
      })
      .catch((err) => {
        console.error('[injectCompanyButtons] listEntities failed:', err);
        toast.error('فشل تحميل قائمة الجهات');
      });
  }

  const collectFormData = () => {
    if (!previewRef.current) return {};
    const inputs = previewRef.current.querySelectorAll('input[data-var]');
    const data = {};
    const hiddenSet = new Set();

    // Count visible inputs per key to detect re-added companies
    const visibleKeys = new Set();
    inputs.forEach(input => {
      if (input.parentElement?.style?.display !== 'none') {
        visibleKeys.add(input.dataset.var);
      }
    });

    inputs.forEach((input) => {
      const key = input.getAttribute('data-var');

      if (input.parentElement?.style?.display === 'none') {
        // Skip if a visible input with the same key exists (company was re-added)
        if (!visibleKeys.has(input.dataset.var)) {
          data[key] = '';
          const idx = COMPANY_GROUPS.findIndex(g =>
            g.company === input.dataset.var || g.budgetS === input.dataset.var || g.budgetF === input.dataset.var
          );
          if (idx > 0) hiddenSet.add(idx);
        }
        return;
      }
      if (input.type === 'checkbox') {
        data[key] = input.checked ? 'True' : '';
      } else {
        data[key] = input.value;
      }
    });

    // Fallback: also read from select[data-var] elements (dropdowns created by injectCompanyButtons)
    const selects = previewRef.current.querySelectorAll('select[data-var]');
    selects.forEach(sel => {
      const key = sel.getAttribute('data-var');
      if (key && sel.value && sel.value !== '__manual__') {
        data[key] = sel.value;
      }
    });

    data._hidden_companies = hiddenSet.size ? [...hiddenSet] : [];
    return data;
  };

  const handleDeleteAttachment = async (attId) => {
    if (!window.confirm('هل أنت متأكد من حذف هذا الملف؟')) return;
    try {
      await contractService.deleteAttachment(attId);
      setAttachments(prev => prev.filter(a => a.id !== attId));
      toast.success('تم حذف الملف');
    } catch {
      toast.error('فشل حذف الملف');
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const getFileIcon = (type) => {
    if (type === 'pdf') return '📄';
    if (type === 'doc' || type === 'docx') return '📝';
    return '📎';
  };

  const handleSave = async () => {
    const domData = collectFormData();
    const mergedData = { ...(contract?.form_data || {}), ...domData };
    setSaving(true);
    try {
      await contractService.update(id, { form_data: mergedData });
      const { data: updatedContract } = await contractService.get(id);
      setContract(updatedContract);
      toast.success('تم حفظ العقد');
      setEditMode(false);
    } catch {
      toast.error('فشل الحفظ');
    } finally {
      setSaving(false);
    }
  };

  const handleWord = async () => {
    try {
      const response = await contractService.downloadWord(id, template);
      downloadFile(response.data, `contract_${contract.contract_number}.docx`);
      toast.success('تم تحميل ملف Word');
    } catch { toast.error('فشل تحميل الملف'); }
  };

  const handlePdf = async () => {
    try {
      const response = await contractService.downloadPdf(id, template);
      downloadFile(response.data, `contract_${contract.contract_number}.pdf`);
      toast.success('تم تحميل ملف PDF');
    } catch { toast.error('فشل تحميل الملف'); }
  };

  const handlePrint = () => window.print();

  if (loading) return <LoadingSpinner />;
  if (!contract) return null;

  return (
    <div>
      {/* Toolbar */}
      <div className="sticky top-0 z-40 -mx-6 -mt-6 px-6 pt-6 pb-4 mb-6 bg-white/80 backdrop-blur-md border-b border-gray-200 no-print">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate('/contracts')} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
              <ArrowRight size={20} className="text-gray-600" />
            </button>
            <h1 className="text-xl font-bold text-gray-900">عرض العقد</h1>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary-50 text-primary-700 text-sm font-semibold border border-primary-200">
              <Hash size={13} />
              {contract.contract_number}
            </span>
          </div>
          <div className="flex items-center gap-1 sm:gap-2 flex-wrap">
            {!editMode && (
              <>
                <button onClick={() => navigate(`/contracts/${id}/edit`)} className="flex items-center gap-1 px-3 py-2 text-sm border rounded-lg bg-primary-600 text-white hover:bg-primary-700 transition-colors disabled:opacity-50">
                  <ExternalLink size={14} /> <span className="hidden sm:inline"> تعديل </span>
                </button>
                <button onClick={() => setEditMode(true)} className="flex items-center gap-1 px-3 py-2 text-sm border rounded-lg bg-primary-600 text-white hover:bg-primary-700 transition-colors disabled:opacity-50">
                  <Pencil size={14} /> <span className="hidden sm:inline">تعديل سريع</span>
                </button>
              </>
            )}
            {editMode && (
              <button onClick={handleSave} disabled={saving} className="flex items-center gap-1 px-4 py-2 text-sm bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors disabled:opacity-50">
                {saving ? <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full" /> : <Save size={14} />}
                <span className="hidden sm:inline">{saving ? 'جاري الحفظ...' : 'حفظ'}</span>
              </button>
            )}
            <button onClick={handleWord} className="flex items-center gap-1 px-3 py-2 text-sm bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
              <FileText size={14} /> <span className="hidden sm:inline">Word</span>
            </button>
            <button
              onClick={() => setShowAttachments(true)}
              className="relative flex items-center gap-1 px-3 py-2 text-sm bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              <Paperclip size={14} /> <span className="hidden sm:inline">المرفقات</span>
              {attachments.length > 0 && (
                <span className="absolute -top-1.5 -left-1.5 w-5 h-5 text-xs font-bold text-white bg-red-500 rounded-full flex items-center justify-center">
                  {attachments.length}
                </span>
              )}
            </button>
            <CustomSelect
              value={template}
              options={[
                { id: 'committee', label: 'Committee' },
                { id: 'summary', label: 'Summary' },
              ]}
              onChange={setTemplate}
            />
            {/* <button onClick={handlePdf} className="flex items-center gap-1 px-3 py-2 text-sm bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
              <FileDown size={14} /> <span className="hidden sm:inline">PDF</span>
            </button>
            <button onClick={handlePrint} className="flex items-center gap-1 px-3 py-2 text-sm bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors">
              <Printer size={14} /> <span className="hidden sm:inline">طباعة</span>
            </button> */}
          </div>
        </div>
      </div>

      {/* Editable Preview */}
      {previewLoading ? (
        <div className="flex justify-center py-20"><LoadingSpinner /></div>
      ) : (
        <div ref={previewRef} dangerouslySetInnerHTML={{ __html: previewHtml }} />
      )}

      {/* Attachments Modal */}
      {showAttachments && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-white rounded-2xl shadow-2xl p-6 max-w-lg w-full mx-4 max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2">
                <Paperclip size={20} className="text-indigo-600" />
                <h3 className="text-lg font-bold text-gray-900">المرفقات</h3>
                {attachments.length > 0 && (
                  <span className="inline-flex items-center justify-center w-6 h-6 text-xs font-bold text-white bg-indigo-500 rounded-full">
                    {attachments.length}
                  </span>
                )}
              </div>
              <button onClick={() => setShowAttachments(false)} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <X size={20} className="text-gray-500" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto">
              {attachments.length > 0 ? (
                <div className="space-y-2">
                  {attachments.map((att) => (
                    <div
                      key={att.id}
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-xl hover:bg-indigo-50 cursor-pointer transition-colors group"
                      onClick={() => setViewerFile(att)}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <span className="text-xl">{getFileIcon(att.file_type)}</span>
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate group-hover:text-indigo-700">{att.original_name}</p>
                          <p className="text-xs text-gray-500">{formatFileSize(att.file_size)}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 shrink-0 mr-2">
                        <a
                          href={att.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="تحميل"
                        >
                          <Download size={16} />
                        </a>
                        <button
                          onClick={(e) => { e.stopPropagation(); handleDeleteAttachment(att.id); }}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="حذف"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-10">
                  <Paperclip size={40} className="mx-auto text-gray-300 mb-3" />
                  <p className="text-sm text-gray-500">لا توجد مرفقات</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* File Viewer Modal */}
      {viewerFile && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-[95vw] max-h-[95vh] flex flex-col overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200">
              <div className="flex items-center gap-3 min-w-0">
                <span className="text-xl">{getFileIcon(viewerFile.file_type)}</span>
                <h3 className="text-base font-bold text-gray-900 truncate">{viewerFile.original_name}</h3>
              </div>
              <div className="flex items-center gap-2 shrink-0 ml-4">
                <a
                  href={viewerFile.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 px-3 py-1.5 text-sm text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
                >
                  <Download size={14} />
                  تحميل
                </a>
                <button
                  onClick={() => setViewerFile(null)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <X size={20} className="text-gray-500" />
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-auto">
              {(viewerFile.file_type === 'pdf') && (
                <>
                  <iframe
                    src={viewerFile.url}
                    className="w-full h-full min-h-[80vh]"
                    title={viewerFile.original_name}
                    onError={(e) => {
                      e.target.style.display = 'none';
                      e.target.nextSibling.style.display = 'flex';
                    }}
                  />
                  <div className="hidden flex-col items-center justify-center py-20">
                    <FileText size={48} className="text-gray-300 mb-4" />
                    <p className="text-gray-500 mb-4">لا يمكن عرض هذا الملف</p>
                    <a href={viewerFile.url} target="_blank" rel="noopener noreferrer"
                      className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors">
                      <Download size={16} /> تحميل الملف
                    </a>
                  </div>
                </>
              )}
              {(viewerFile.file_type === 'doc' || viewerFile.file_type === 'docx') && (
                <div className="flex flex-col items-center justify-center py-20">
                  <FileText size={48} className="text-indigo-300 mb-4" />
                  <p className="text-gray-700 font-medium mb-2">{viewerFile.original_name}</p>
                  <p className="text-gray-500 mb-6">ملف Word - اضغط للتحميل</p>
                  <div className="flex gap-3">
                    <a href={viewerFile.url} target="_blank" rel="noopener noreferrer"
                      className="flex items-center gap-2 px-5 py-2.5 bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-colors font-medium">
                      <ExternalLink size={16} /> فتح الملف
                    </a>
                    <a href={viewerFile.url} download={viewerFile.original_name}
                      className="flex items-center gap-2 px-5 py-2.5 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors font-medium">
                      <Download size={16} /> تحميل
                    </a>
                  </div>
                </div>
              )}
              {(viewerFile.file_type !== 'pdf' && viewerFile.file_type !== 'doc' && viewerFile.file_type !== 'docx') && (
                <div className="flex flex-col items-center justify-center py-20">
                  <FileText size={48} className="text-gray-300 mb-4" />
                  <p className="text-gray-500 mb-4">لا يمكن عرض هذا الملف في المتصفح</p>
                  <a href={viewerFile.url} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors">
                    <Download size={16} /> تحميل الملف
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}