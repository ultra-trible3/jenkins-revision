import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { contractService } from '../services/contractService';
import DashboardCard from '../components/DashboardCard';
import LoadingSpinner from '../components/LoadingSpinner';
import { FileText, Calendar, PlusCircle, ArrowLeft } from 'lucide-react';

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    contractService.stats()
      .then(({ data }) => setStats(data))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingSpinner />;

  const today = new Date().toLocaleDateString('ar-SA', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
  });

  const maxDailyTarget = 50;
  const todayCount = stats?.contracts_today ?? 0;
  const progress = Math.min(todayCount / maxDailyTarget, 1);
  const circumference = 2 * Math.PI * 42;
  const offset = circumference * (1 - progress);

  const quickActions = [
    { label: 'إنشاء عقد جديد', icon: PlusCircle, onClick: () => navigate('/contracts/new'), color: 'text-green-600', bg: 'bg-green-50', hover: 'hover:bg-green-100' },
    { label: 'عرض العقود', icon: FileText, onClick: () => navigate('/contracts'), color: 'text-primary-600', bg: 'bg-primary-50', hover: 'hover:bg-primary-100' },
  ];

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            مرحباً، {user?.username || 'المستخدم'}
          </h1>
          <p className="text-gray-500 mt-1">{today}</p>
        </div>
        <div className="flex items-center gap-2.5 px-4 py-2.5 bg-white rounded-xl border border-gray-200 shadow-sm">
          <FileText size={18} className="text-primary-500" />
          <span className="text-sm text-gray-600">إجمالي العقود: </span>
          <span className="font-bold text-lg text-primary-600">{stats?.total_contracts ?? 0}</span>
        </div>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <DashboardCard
          title="إجمالي العقود"
          value={stats?.total_contracts ?? 0}
          icon={FileText}
          gradient="from-primary-500 to-primary-600"
          iconBg="bg-primary-100 text-primary-600"
          onClick={() => navigate('/contracts')}
        />
        <DashboardCard
          title="عقود اليوم"
          value={stats?.contracts_today ?? 0}
          icon={Calendar}
          gradient="from-amber-500 to-amber-600"
          iconBg="bg-amber-100 text-amber-600"
        />
        <DashboardCard
          title="عقد جديد"
          value="إنشاء لجنة ممارسة"
          icon={PlusCircle}
          subtitle=""
          gradient="from-purple-500 to-purple-600"
          iconBg="bg-purple-100 text-purple-600"
          onClick={() => navigate('/contracts/new')}
        />
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quick Actions */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <h2 className="text-lg font-bold text-gray-900 mb-5">إجراءات سريعة</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {quickActions.map((action) => (
              <button
                key={action.label}
                onClick={action.onClick}
                className={`flex items-center gap-3 p-4 ${action.bg} ${action.color} rounded-xl transition-all duration-200 hover:shadow-md hover:-translate-y-0.5 font-medium group ${action.hover}`}
              >
                <div className={`p-2.5 rounded-xl ${action.bg} ${action.color} group-hover:scale-110 transition-transform`}>
                  <action.icon size={22} />
                </div>
                <span className="text-sm">{action.label}</span>
                <ArrowLeft size={16} className="mr-auto opacity-0 group-hover:opacity-100 transition-opacity" />
              </button>
            ))}
          </div>
        </div>

        {/* Activity Summary */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <h2 className="text-lg font-bold text-gray-900 mb-5">نشاط اليوم</h2>
          <div className="flex flex-col items-center justify-center py-4">
            <div className="relative w-28 h-28 mb-4">
              <svg className="w-28 h-28 -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="42" fill="none" stroke="#e5e7eb" strokeWidth="8" />
                <circle
                  cx="50" cy="50" r="42"
                  fill="none"
                  stroke="oklch(66.6% 0.179 58.318)"
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={`${circumference}`}
                  strokeDashoffset={offset}
                  className="transition-all duration-1000 ease-out"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-2xl font-bold text-amber-600 ">{todayCount}</span>
              </div>
            </div>
            <p className="text-sm text-gray-500 text-center leading-relaxed">
              عقداً تم إنشاؤها اليوم
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}