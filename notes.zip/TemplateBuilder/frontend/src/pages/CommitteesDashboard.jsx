import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { contractService } from '../services/contractService';
import DashboardCard from '../components/DashboardCard';
import LoadingSpinner from '../components/LoadingSpinner';
import { ClipboardList, PlusCircle, FileText, Users, Landmark, Building2, ArrowLeft } from 'lucide-react';

export default function CommitteesDashboard() {
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    contractService.committeeStats()
      .then(({ data }) => setStats(data))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingSpinner />;

  const quickActions = [
    { label: 'إنشاء لجنة جديدة', icon: PlusCircle, onClick: () => navigate('/contracts/new/editor?contract_type=1'), color: 'text-green-600', bg: 'bg-green-50', hover: 'hover:bg-green-100' },
    { label: 'عرض جميع اللجان', icon: FileText, onClick: () => navigate('/contracts'), color: 'text-primary-600', bg: 'bg-primary-50', hover: 'hover:bg-primary-100' },
    { label: 'أعضاء اللجنة', icon: Users, onClick: () => navigate('/members'), color: 'text-purple-600', bg: 'bg-purple-50', hover: 'hover:bg-purple-100' },
    { label: 'الجهات', icon: Landmark, onClick: () => navigate('/entities'), color: 'text-amber-600', bg: 'bg-amber-50', hover: 'hover:bg-amber-100' },
    { label: 'الشركات', icon: Building2, onClick: () => navigate('/companies'), color: 'text-blue-600', bg: 'bg-blue-50', hover: 'hover:bg-blue-100' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-primary-100 text-primary-600">
            <ClipboardList size={28} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">لجان الممارسة</h1>
            <p className="text-gray-500 mt-1">إدارة ومتابعة لجان الممارسة</p>
          </div>
        </div>
        <div className="flex items-center gap-2.5 px-4 py-2.5 bg-white rounded-xl border border-gray-200 shadow-sm">
          <ClipboardList size={18} className="text-primary-500" />
          <span className="text-sm text-gray-600">إجمالي اللجان: </span>
          <span className="font-bold text-lg text-primary-600">{stats?.total_committees ?? 0}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <DashboardCard
          title="إجمالي اللجان"
          value={stats?.total_committees ?? 0}
          icon={ClipboardList}
          gradient="from-primary-500 to-primary-600"
          iconBg="bg-primary-100 text-primary-600"
          onClick={() => navigate('/contracts')}
        />
        <DashboardCard
          title="لجان اليوم"
          value={stats?.committees_today ?? 0}
          icon={FileText}
          gradient="from-amber-500 to-amber-600"
          iconBg="bg-amber-100 text-amber-600"
        />
        <DashboardCard
          title="لجنة جديدة"
          value="إنشاء لجنة"
          icon={PlusCircle}
          subtitle=""
          gradient="from-purple-500 to-purple-600"
          iconBg="bg-purple-100 text-purple-600"
          onClick={() => navigate('/contracts/new/editor?contract_type=1')}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <h2 className="text-lg font-bold text-gray-900 mb-5">إجراءات سريعة</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {quickActions.map((action) => (
              <button
                key={action.label}
                onClick={action.onClick}
                className={`flex items-center gap-3 p-4 ${action.bg} ${action.color} rounded-xl transition-all duration-200 hover:shadow-md hover:-translate-y-0.5 font-medium group ${action.hover}`}
              >
                <div className={`p-2.5 rounded-xl ${action.bg} ${action.color} group-hover:scale-110 transition-transform`}>
                  <action.icon size={22} />
                </div>
                <span className="text-sm">{action.label}</span>
                <ArrowLeft size={16} className="mr-auto opacity-0 group-hover:opacity-100 transition-opacity" />
              </button>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <h2 className="text-lg font-bold text-gray-900 mb-5">آخر اللجان</h2>
          {stats?.recent_committees?.length > 0 ? (
            <div className="space-y-3">
              {stats.recent_committees.map((c) => (
                <div
                  key={c.id}
                  onClick={() => navigate(`/contracts/${c.id}`)}
                  className="flex items-center justify-between p-3 rounded-xl bg-gray-50 hover:bg-primary-50 cursor-pointer transition-colors group"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate group-hover:text-primary-700">
                      {c.description || c.contract_number}
                    </p>
                    <p className="text-xs text-gray-500 mt-0.5">{c.date}</p>
                  </div>
                  <ArrowLeft size={14} className="text-gray-400 group-hover:text-primary-500 shrink-0 mr-2" />
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <ClipboardList size={40} className="mx-auto text-gray-300 mb-3" />
              <p className="text-sm text-gray-500">لا توجد لجان مسجلة</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
