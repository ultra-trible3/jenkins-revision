import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { contractService } from '../services/contractService';
import { useToast } from '../hooks/useToast';
import { ArrowRight, Save } from 'lucide-react';

export default function CreateContract() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const toast = useToast();
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const templateName = searchParams.get('template') || 'committee';
      const contractTypeId = searchParams.get('contract_type');
      const payload = {
        template_name: templateName,
        form_data: {},
      };
      if (contractTypeId) payload.contract_type_id = parseInt(contractTypeId);
      const { data } = await contractService.create(payload);
      toast.success('تم إنشاء العقد بنجاح');
      navigate(`/contracts/${data.id}/edit`);
    } catch (err) {
      if (err.response?.data) {
        const serverErrors = {};
        Object.entries(err.response.data).forEach(([key, val]) => { serverErrors[key] = Array.isArray(val) ? val[0] : val; });
        setErrors(serverErrors);
      }
      toast.error('فشل إنشاء العقد');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate('/contracts')} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
          <ArrowRight size={20} className="text-gray-600" />
        </button>
        <h1 className="text-2xl font-bold text-gray-900">إنشاء عقد جديد</h1>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex gap-3 mt-0 pt-0 border-t-0 border-gray-100">
          <button type="submit" disabled={loading} className="flex items-center gap-2 bg-primary-600 text-white px-6 py-2.5 rounded-lg hover:bg-primary-700 transition-colors text-sm font-medium disabled:opacity-50">
            {loading ? 'جاري الإنشاء...' : <><Save size={16} /> إنشاء وفتح المحرر</>}
          </button>
          <button type="button" onClick={() => navigate('/contracts')} className="px-6 py-2.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors">
            إلغاء
          </button>
        </div>
      </form>
    </div>
  );
}
