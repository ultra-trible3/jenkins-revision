import { useState, useEffect, useRef, forwardRef, useImperativeHandle } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { contractService } from '../services/contractService';
import LoadingSpinner from '../components/LoadingSpinner';
import { useToast } from '../hooks/useToast';
import { ArrowRight, Save, Eye, FileText, BarChart3, Users, Hash, Plus, X, ChevronDown, CheckCircle, Paperclip, Trash2, Download } from 'lucide-react';
import { getFieldConfig, TEMPLATE_CONFIGS, normalizeFormData } from '../config/variableConfig';

const ICON_MAP = { FileText, BarChart3 };

const COMPANY_GROUPS = [
  { company: 'company1', budgetS: 'input3_budget_s', budgetF: 'input3_budget_f' },
  { company: 'company2', budgetS: 'input4_budget_s', budgetF: 'input4_budget_f' },
  { company: 'company3', budgetS: 'input5_budget_s', budgetF: 'input5_budget_f' },
  { company: 'company4', budgetS: 'input6_budget_s', budgetF: 'input6_budget_f' },
  { company: 'company5', budgetS: 'input7_budget_s', budgetF: 'input7_budget_f' },
];
const ALL_COMPANY_KEYS = COMPANY_GROUPS.flatMap(g => [g.company, g.budgetS, g.budgetF]);
const COMPANY_LABELS = ['الشركة الأولى', 'الشركة الثانية', 'الشركة الثالثة', 'الشركة الرابعة', 'الشركة الخامسة'];

const inputClass = "w-full px-4 py-3 border border-gray-200 rounded-xl outline-none text-sm transition-all duration-200 focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 bg-white";
const labelClass = "block text-sm font-semibold text-gray-700 mb-1.5";

const DynamicForm = forwardRef(function DynamicForm({ formData, onChange, templateName, fieldErrors = {} }, ref) {
  const handleChange = (key) => (e) => {
    if (isOneOffer && DISABLED_KEYS.includes(key)) return;
    onChange({ ...formData, [key]: e.target.value });
  };

  const config = TEMPLATE_CONFIGS[templateName];
  const pages = config?.pages || [];
  const [expandedPage, setExpandedPage] = useState(-1);

  const togglePage = (index) => {
    setExpandedPage(prev => prev === index ? -1 : index);
  };

  const isOneOffer = formData.isOneOffer === 'True';
  const DISABLED_KEYS = [
    'company2', 'company3', 'company4', 'company5',
    'input4_budget_s', 'input5_budget_s', 'input6_budget_s', 'input7_budget_s',
    'input4_budget_f', 'input5_budget_f', 'input6_budget_f', 'input7_budget_f',
  ];
  const disabledSuffix = ' bg-gray-100 text-gray-500 border-gray-300 cursor-not-allowed';
  const disabledLabelSuffix = ' text-gray-400';
  const errorClass = 'border-red-500 ring-2 ring-red-500/20';

  const [companyCount, setCompanyCount] = useState(() => {
    const filled = COMPANY_GROUPS.filter(g => formData[g.company]?.trim()).length;
    return Math.max(1, filled);
  });

  const [companiesList, setCompaniesList] = useState([]);
  const [manualMode, setManualMode] = useState({});
  const [selectedCompany, setSelectedCompany] = useState(() => formData._selected_company || null);

  useEffect(() => {
    contractService.listCompanies()
      .then(({ data }) => setCompaniesList(data.results || data))
      .catch(() => { });
    contractService.listMembers()
      .then(({ data }) => setMembersList(data.results || data))
      .catch(() => { });
    contractService.listEntities()
      .then(({ data }) => setEntitiesList(data.results || data))
      .catch(() => { });
  }, []);

  const [membersList, setMembersList] = useState([]);
  const [memberManualMode, setMemberManualMode] = useState({});
  const [entitiesList, setEntitiesList] = useState([]);

  const handleMemberSelect = (key, value) => {
    if (value === '__manual__') {
      setMemberManualMode(prev => ({ ...prev, [key]: true }));
      onChange({ ...formData, [key]: '' });
    } else {
      setMemberManualMode(prev => ({ ...prev, [key]: false }));
      onChange({ ...formData, [key]: value });
    }
  };

  const handleCompanySelect = (key, value) => {
    if (value === '__manual__') {
      setManualMode(prev => ({ ...prev, [key]: true }));
      onChange({ ...formData, [key]: '' });
    } else {
      setManualMode(prev => ({ ...prev, [key]: false }));
      onChange({ ...formData, [key]: value });
    }
  };

  const addCompany = () => {
    if (companyCount < 5) setCompanyCount(c => c + 1);
  };

  const removeCompany = (index) => {
    const g = COMPANY_GROUPS[index];
    const newData = { ...formData };
    [g.company, g.budgetS, g.budgetF].forEach(k => delete newData[k]);
    onChange(newData);
    setCompanyCount(c => c - 1);
  };

  useImperativeHandle(ref, () => ({
    validate: () => {
      const invalidFields = [];
      const config = TEMPLATE_CONFIGS[templateName];
      const pages = config?.pages || [];
      const seen = new Set();

      pages.forEach(page => {
        const memberKeys = page.memberKeys || [];
        page.keys.forEach(key => {
          if (seen.has(key)) return;
          seen.add(key);
          if (ALL_COMPANY_KEYS.includes(key)) return;

          const field = getFieldConfig(key);
          if (!field) return;
          if (field.type === 'checkbox') return;
          if (field.type === 'range') return;

          const val = formData[key];
          if (field.type === 'number') {
            if (!val || !String(val).trim()) {
              invalidFields.push(key);
            } else if (isNaN(Number(val))) {
              invalidFields.push(key);
            } else if (field.min !== undefined && Number(val) < field.min) {
              invalidFields.push(key);
            } else if (field.max !== undefined && Number(val) > field.max) {
              invalidFields.push(key);
            }
          } else {
            if (!val || !String(val).trim()) {
              invalidFields.push(key);
            }
          }
        });

        memberKeys.forEach(key => {
          if (seen.has(key)) return;
          seen.add(key);
          const field = getFieldConfig(key);
          if (!field) return;
          const val = formData[key];
          if (!val || !String(val).trim()) {
            invalidFields.push(key);
          }
        });
      });

      const hasCompanyFields = pages.some(page =>
        page.keys.some(key => ALL_COMPANY_KEYS.includes(key))
      );

      if (hasCompanyFields) {
        for (let i = 0; i < companyCount; i++) {
          const g = COMPANY_GROUPS[i];
          if (!formData[g.company] || !String(formData[g.company]).trim()) {
            invalidFields.push(g.company);
          }
          if (!formData[g.budgetS] || !String(formData[g.budgetS]).trim()) {
            invalidFields.push(g.budgetS);
          } else if (isNaN(Number(formData[g.budgetS]))) {
            invalidFields.push(g.budgetS);
          }
          if (!formData[g.budgetF] || !String(formData[g.budgetF]).trim()) {
            invalidFields.push(g.budgetF);
          } else if (isNaN(Number(formData[g.budgetF]))) {
            invalidFields.push(g.budgetF);
          }
        }
      }

      return { valid: invalidFields.length === 0, invalidFields };
    }
  }));

  function renderCompanyCard(index) {
    const g = COMPANY_GROUPS[index];
    const disabled = isOneOffer && index > 0;
    const companyConfig = getFieldConfig(g.company);
    const budgetSConfig = getFieldConfig(g.budgetS);
    const budgetFConfig = getFieldConfig(g.budgetF);

    return (
      <div
        key={g.company}
        className={`border-2 rounded-xl p-5 relative transition-all duration-200 ${selectedCompany === g.company
            ? 'border-amber-500 shadow-lg shadow-amber-200/50 bg-amber-50'
            : 'border-amber-200 bg-white hover:border-amber-300'
          }`}
      >
        {index > 0 && (
          <button type="button" onClick={() => removeCompany(index)}
            className="absolute -top-2.5 -left-2.5 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center hover:bg-red-600 transition-colors shadow-sm"
          >
            <X size={14} />
          </button>
        )}
        <h5 className="text-sm font-bold text-amber-800 mb-4 pb-2 border-b border-amber-100 flex items-center justify-between">
          <span>{COMPANY_LABELS[index]}</span>
          <label className="flex items-center gap-2 cursor-pointer" onClick={(e) => e.stopPropagation()}>
            <input
              type="checkbox"
              checked={selectedCompany === g.company}
              onChange={() => {
                const newVal = selectedCompany === g.company ? null : g.company;
                setSelectedCompany(newVal);
                onChange({ ...formData, _selected_company: newVal });
              }}
              className="w-4 h-4 rounded border-gray-300 text-amber-500 focus:ring-amber-500"
            />
            <span className="text-xs font-semibold text-amber-700">المصدّق عليها</span>
          </label>
        </h5>
        <div className="grid grid-cols-1 gap-4">
          <div>
            <label className={`${labelClass}${disabled ? disabledLabelSuffix : ''}`}>{companyConfig?.label || g.company}</label>
            {manualMode[g.company] ? (
              <div className="flex gap-2">
                <input type="text" value={formData[g.company] || ''} onChange={handleChange(g.company)} disabled={disabled}
                  placeholder="أدخل اسم الشركة..."
                  className={`${inputClass}${disabled ? disabledSuffix : ''}${fieldErrors[g.company] ? ` ${errorClass}` : ''}`} />
                <button type="button" onClick={() => {
                  setManualMode(prev => ({ ...prev, [g.company]: false }));
                  onChange({ ...formData, [g.company]: '' });
                }} className="px-3 py-2 text-xs text-gray-600 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors whitespace-nowrap">
                  القائمة
                </button>
              </div>
            ) : (
              <div className="relative">
                <select
                  value={formData[g.company] || ''}
                  onChange={(e) => handleCompanySelect(g.company, e.target.value)}
                  disabled={disabled}
                  className={`${inputClass} appearance-none bg-no-repeat${disabled ? disabledSuffix : ''}${fieldErrors[g.company] ? ` ${errorClass}` : ''}`}
                  style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%239ca3af' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E\")", backgroundPosition: 'left 12px center', backgroundSize: '12px', backgroundRepeat: 'no-repeat', paddingLeft: '36px', WebkitAppearance: 'none', MozAppearance: 'none' }}
                >
                  <option value="">اختر شركة...</option>
                  {companiesList.map((c) => (
                    <option key={c.id} value={c.name}>{c.name}</option>
                  ))}
                  {formData[g.company] && !companiesList.some(c => c.name === formData[g.company]) && (
                    <option value={formData[g.company]}>{formData[g.company]}</option>
                  )}
                  <option value="__manual__">+ إدخال يدوي</option>
                </select>
              </div>
            )}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={`${labelClass}${disabled ? disabledLabelSuffix : ''}`}>{budgetSConfig?.label || g.budgetS}</label>
              <input type="text" inputMode="numeric" value={formData[g.budgetS] || ''} onChange={handleChange(g.budgetS)} disabled={disabled}
                className={`${inputClass}${disabled ? disabledSuffix : ''}${fieldErrors[g.budgetS] ? ` ${errorClass}` : ''}`} />
            </div>
            <div>
              <label className={`${labelClass}${disabled ? disabledLabelSuffix : ''}`}>{budgetFConfig?.label || g.budgetF}</label>
              <input type="text" inputMode="numeric" value={formData[g.budgetF] || ''} onChange={handleChange(g.budgetF)} disabled={disabled}
                className={`${inputClass}${disabled ? disabledSuffix : ''}${fieldErrors[g.budgetF] ? ` ${errorClass}` : ''}`} />
            </div>
          </div>
        </div>
      </div>
    );
  }

  function renderField(f) {
    const val = formData[f.key] || '';
    const key = f.key;
    const disabled = isOneOffer && DISABLED_KEYS.includes(key);

    if (f.type === 'select') {
      return (
        <div key={key}>
          <label className={`${labelClass}${disabled ? disabledLabelSuffix : ''}`}>{f.label}</label>
          <select value={val} onChange={handleChange(key)} disabled={disabled} className={`${inputClass} appearance-none bg-no-repeat${disabled ? disabledSuffix : ''}${fieldErrors[key] ? ` ${errorClass}` : ''}`} style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%239ca3af' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E\")", backgroundPosition: 'left 12px center', backgroundSize: '12px', backgroundRepeat: 'no-repeat', paddingLeft: '36px', WebkitAppearance: 'none', MozAppearance: 'none' }}>
            <option value="">-- اختر --</option>
            {f.options.map((opt) => <option key={opt} value={opt}>{opt}</option>)}
          </select>
        </div>
      );
    }

    if (f.type === 'range') {
      return (
        <div key={key} className="md:col-span-2">
          <label className={`${labelClass}${disabled ? disabledLabelSuffix : ''}`}>{f.label}</label>
          <div className={`flex items-center gap-4 ${disabled ? 'bg-gray-100 border-gray-300' : 'bg-white border-gray-200'} rounded-xl border px-4 py-3${fieldErrors[key] ? ` ${errorClass}` : ''}`}>
            <input
              type="range"
              min={f.min ?? 0}
              max={f.max ?? 100}
              value={val || 0}
              onChange={handleChange(key)}
              disabled={disabled}
              className={`flex-1 h-2 rounded-full appearance-none cursor-pointer accent-primary-500 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-primary-500 [&::-webkit-slider-thumb]:shadow-md [&::-webkit-slider-thumb]:cursor-pointer [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-white${disabled ? disabledSuffix : ''}`}
            />
            <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-semibold min-w-12 justify-center${disabled ? ' bg-gray-200 text-gray-500' : ' bg-primary-50 text-primary-700'}`}>
              {val || 0}%
            </span>
          </div>
        </div>
      );
    }

    if (f.type === 'checkbox') {
      return (
        <div key={key}>
          <label className={`${labelClass} flex items-center gap-3 cursor-pointer select-none`}>
            <input type="checkbox" checked={formData[f.key] === 'True'}
              onChange={() => onChange({ ...formData, [f.key]: formData[f.key] === 'True' ? '' : 'True' })}
              className="w-5 h-5 rounded border-gray-300 text-primary-600 focus:ring-primary-500 cursor-pointer" />
            <span>{f.label}</span>
          </label>
        </div>
      );
    }

    if (f.type === 'textarea') {
      if (key === 'input_text_area') {
        return (
          <div key={key} className="md:col-span-2">
            <label className={`${labelClass}${disabled ? disabledLabelSuffix : ''}`}>{f.label}</label>
            <div className="relative">
              <select
                value={val}
                onChange={handleChange(key)}
                disabled={disabled}
                className={`${inputClass} appearance-none bg-no-repeat${disabled ? disabledSuffix : ''}${fieldErrors[key] ? ` ${errorClass}` : ''}`}
                style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%239ca3af' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E\")", backgroundPosition: 'left 12px center', backgroundSize: '12px', backgroundRepeat: 'no-repeat', paddingLeft: '36px', WebkitAppearance: 'none', MozAppearance: 'none' }}
              >
                <option value="">اختر الجهة...</option>
                {entitiesList.map((e) => (
                  <option key={e.id} value={e.name}>{e.name}</option>
                ))}
                {val && !entitiesList.some(e => e.name === val) && (
                  <option value={val}>{val}</option>
                )}
              </select>
            </div>
          </div>
        );
      }
      return (
        <div key={key} className="md:col-span-2">
          <label className={`${labelClass}${disabled ? disabledLabelSuffix : ''}`}>{f.label}</label>
          <textarea value={val} onChange={handleChange(key)} disabled={disabled} rows={4} className={`${inputClass} resize-y${disabled ? disabledSuffix : ''}${fieldErrors[key] ? ` ${errorClass}` : ''}`} />
        </div>
      );
    }

    const inputType = f.type === 'date' ? 'date' : f.type === 'time' ? 'time' : f.type === 'number' ? 'number' : 'text';
    return (
      <div key={key}>
        <label className={`${labelClass}${disabled ? disabledLabelSuffix : ''}`}>{f.label}</label>
        <input type={inputType} value={val} onChange={handleChange(key)} disabled={disabled} className={`${inputClass}${disabled ? disabledSuffix : ''}${fieldErrors[key] ? ` ${errorClass}` : ''}`} />
      </div>
    );
  }

  function renderMemberField(f) {
    const val = formData[f.key] || '';
    const key = f.key;
    const MEMBER_ROLE_MAP = {
      'list_member[0]': 'chair',
      'list_member[1]': 'financial',
      'list_member[2]': 'company',
      'list_member[3]': 'technical',
    };
    const role = MEMBER_ROLE_MAP[key];
    const filteredMembers = membersList.filter(m => m.role === role);

    if (memberManualMode[key]) {
      return (
        <div key={key}>
          <label className={`${labelClass}${fieldErrors[key] ? ` ${errorClass}` : ''}`}>{f.label}</label>
          <div className="flex gap-2">
            <input type="text" value={val} onChange={handleChange(key)}
              placeholder="أدخل اسم العضو..."
              className={`${inputClass}${fieldErrors[key] ? ` ${errorClass}` : ''}`} />
            <button type="button" onClick={() => {
              setMemberManualMode(prev => ({ ...prev, [key]: false }));
              onChange({ ...formData, [key]: '' });
            }} className="px-3 py-2 text-xs text-gray-600 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors whitespace-nowrap">
              القائمة
            </button>
          </div>
        </div>
      );
    }

    return (
      <div key={key}>
        <label className={`${labelClass}${fieldErrors[key] ? ` ${errorClass}` : ''}`}>{f.label}</label>
        <div className="relative">
          <select
            value={val}
            onChange={(e) => handleMemberSelect(key, e.target.value)}
            className={`${inputClass} appearance-none bg-no-repeat${fieldErrors[key] ? ` ${errorClass}` : ''}`}
            style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%239ca3af' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E\")", backgroundPosition: 'left 12px center', backgroundSize: '12px', backgroundRepeat: 'no-repeat', paddingLeft: '36px', WebkitAppearance: 'none', MozAppearance: 'none' }}
          >
            <option value="">اختر عضو...</option>
            {filteredMembers.map((m) => (
              <option key={m.id} value={m.name}>{m.name}</option>
            ))}
            {val && !filteredMembers.some(m => m.name === val) && (
              <option value={val}>{val}</option>
            )}
            <option value="__manual__">+ إدخال يدوي</option>
          </select>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {pages.map((page, index) => {
        const fields = page.keys.map(getFieldConfig).filter(Boolean);
        const memberKeys = page.memberKeys || [];
        const memberFields = memberKeys.map(getFieldConfig).filter(Boolean);
        const nonCompanyFields = fields.filter(f => !ALL_COMPANY_KEYS.includes(f.key));
        const nonMemberFields = nonCompanyFields.filter(f => !memberKeys.includes(f.key));
        const pageHasCompany = fields.some(f => ALL_COMPANY_KEYS.includes(f.key));
        const Icon = ICON_MAP[page.icon] || FileText;
        const isExpanded = expandedPage === index;
        return (
          <div key={page.title} className={`${page.color} border ${page.border} rounded-2xl shadow-sm`}>
            <button
              type="button"
              onClick={() => togglePage(index)}
              className="flex items-center justify-between w-full p-7 pb-4"
            >
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-xl ${page.iconBg}`}>
                  <Icon size={20} />
                </div>
                <h3 className={`text-base font-bold ${page.header}`}>{page.title}</h3>
              </div>
              <ChevronDown size={18} className={`transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`} />
            </button>

            <div
              className="overflow-hidden transition-all duration-300 ease-in-out"
              style={{ maxHeight: isExpanded ? '2000px' : '0' }}
            >
              <div className="px-7 pb-7">
                <div className="mb-6 border-b border-inherit" />

                {nonMemberFields.length > 0 && (
                  <div className="grid grid-cols-1 items-end md:grid-cols-2 gap-5">
                    {nonMemberFields.map(renderField)}
                  </div>
                )}

                {pageHasCompany && (
                  <div className="mt-6 bg-amber-50/60 border border-amber-200/60 rounded-xl p-5">
                    <div className="flex items-center justify-between mb-4 pb-2 border-b border-amber-200">
                      <div className="flex items-center gap-2">
                        <FileText size={16} className="text-amber-700" />
                        <h4 className="text-sm font-bold text-amber-800">الشركات المتقدمة</h4>
                      </div>
                      {companyCount < 5 && (
                        <button type="button" onClick={addCompany}
                          className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold bg-amber-100 text-amber-800 rounded-lg hover:bg-amber-200 transition-colors"
                        >
                          <Plus size={14} /> إضافة شركة
                        </button>
                      )}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {COMPANY_GROUPS.slice(0, companyCount).map((_, i) => renderCompanyCard(i))}
                    </div>
                  </div>
                )}

                {memberFields.length > 0 && (
                  <div className="mt-6 bg-white/80 border border-blue-100 rounded-xl p-5">
                    <div className="flex items-center gap-2 mb-4 pb-2 border-b border-blue-100">
                      <Users size={16} className="text-blue-600" />
                      <h4 className="text-sm font-bold text-blue-800">أعضاء اللجنة</h4>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {memberFields.map(renderMemberField)}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
});

export default function EditContract() {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const toast = useToast();
  const [form, setForm] = useState(null);
  const [formData, setFormData] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const formRef = useRef(null);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [createdContract, setCreatedContract] = useState(null);
  const [fieldErrors, setFieldErrors] = useState({});
  const [attachments, setAttachments] = useState([]);
  const [attachmentsExpanded, setAttachmentsExpanded] = useState(false);
  const [trainingExpanded, setTrainingExpanded] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  const handleFormChange = (newData) => {
    setFormData(newData);
    if (Object.keys(fieldErrors).length > 0) setFieldErrors({});
  };

  useEffect(() => {
    if (id && id !== 'new') {
      contractService.get(id)
        .then(({ data }) => {
          const normalized = normalizeFormData(data.form_data || {});
          setForm({
            contract_number: data.contract_number,
            template_name: data.template_name,
          });
          setFormData(normalized);
          contractService.listAttachments(id)
            .then(({ data: attData }) => setAttachments(attData.results || attData))
            .catch(() => {});
        })
        .catch(() => { toast.error('فشل تحميل العقد'); navigate('/contracts'); })
        .finally(() => setLoading(false));
    } else {
      setForm({
        contract_number: '',
        template_name: searchParams.get('template') || 'committee',
        contract_type_id: searchParams.get('contract_type') ? Number(searchParams.get('contract_type')) : null,
      });
      setFormData({});
      setLoading(false);
    }
  }, [id, navigate]);

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    const contractId = id && id !== 'new' ? id : null;
    setUploading(true);
    try {
      for (const file of files) {
        const { data } = await contractService.uploadAttachment(contractId, file);
        setAttachments(prev => [data, ...prev]);
      }
      toast.success('تم رفع الملف بنجاح');
    } catch {
      toast.error('فشل رفع الملف');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleDeleteAttachment = async (attId) => {
    if (!window.confirm('هل أنت متأكد من حذف هذا الملف؟')) return;
    try {
      await contractService.deleteAttachment(attId);
      setAttachments(prev => prev.filter(a => a.id !== attId));
      toast.success('تم حذف الملف');
    } catch {
      toast.error('فشل حذف الملف');
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const getFileIcon = (type) => {
    if (type === 'pdf') return '📄';
    if (type === 'doc' || type === 'docx') return '📝';
    return '📎';
  };

  const handleSave = async () => {
    const { valid, invalidFields } = formRef.current?.validate() || {};
    if (!valid) {
      setFieldErrors(Object.fromEntries(invalidFields.map(k => [k, true])));
      toast.error('لم يتم ادخال كل البيانات');
      return;
    }

    setSaving(true);
    try {
      const payload = {
        template_name: form.template_name,
        form_data: formData,
      };
      if (form.contract_type_id) payload.contract_type_id = form.contract_type_id;
      const { data } = id && id !== 'new'
        ? await contractService.update(id, payload)
        : await contractService.create(payload);

      const pendingAttachments = attachments.filter(a => !a.contract);
      if (pendingAttachments.length > 0) {
        for (const att of pendingAttachments) {
          await contractService.attachToContract(att.id, data.id);
        }
      }

      setCreatedContract({
        id: data.id,
        number: data.contract_number,
        isNew: !id || id === 'new',
      });
      setShowSuccessModal(true);
    } catch (err) {
      toast.error(err.response?.data?.contract_number?.[0] || 'فشل حفظ العقد');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <LoadingSpinner />;
  if (!form) return null;

  const isNew = !id || id === 'new';

  return (
    <div>
      {/* Sticky Header */}
      <div className="sticky top-0 z-40 -mx-6 -mt-6 px-6 pt-6 pb-4 mb-6 bg-white/80 backdrop-blur-md border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate('/contracts')} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
              <ArrowRight size={20} className="text-gray-600" />
            </button>
            <h1 className="text-xl font-bold text-gray-900">
              {isNew ? 'ملئ العقد' : 'تعديل العقد'}
            </h1>
            {!isNew && (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary-50 text-primary-700 text-sm font-semibold border border-primary-200">
                <Hash size={13} />
                {form.contract_number}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex items-center gap-2 px-6 py-2.5 text-sm font-semibold bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-all duration-200 shadow-sm hover:shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {saving ? (
                <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full" />
              ) : (
                <Save size={16} />
              )}
              {saving ? 'جاري الحفظ...' : 'حفظ'}
            </button>
            {!isNew && (
              <button
                onClick={() => navigate(`/contracts/${id}`)}
                className="flex items-center gap-2 px-4 py-2.5 text-sm font-medium border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors text-gray-700"
              >
                <Eye size={16} />
                عرض
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Form Panel */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-7">
        <DynamicForm ref={formRef} formData={formData} onChange={handleFormChange} templateName={form.template_name} fieldErrors={fieldErrors} />
      </div>

      {/* Attachments Panel */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm mt-6">
        <button
          type="button"
          onClick={() => setAttachmentsExpanded(!attachmentsExpanded)}
          className="flex items-center justify-between w-full p-7 pb-4"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-indigo-100 text-indigo-600">
              <Paperclip size={20} />
            </div>
            <h3 className="text-base font-bold text-indigo-800">المرفقات</h3>
            {attachments.length > 0 && (
              <span className="inline-flex items-center justify-center w-6 h-6 text-xs font-bold text-white bg-indigo-500 rounded-full">
                {attachments.length}
              </span>
            )}
          </div>
          <ChevronDown size={18} className={`transition-transform duration-200 ${attachmentsExpanded ? 'rotate-180' : ''}`} />
        </button>

        <div
          className="overflow-hidden transition-all duration-300 ease-in-out"
          style={{ maxHeight: attachmentsExpanded ? '2000px' : '0' }}
        >
          <div className="px-7 pb-7">
            <div className="mb-6 border-b border-indigo-100" />

            {/* Upload Area */}
            <div className="mb-4">
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept=".pdf,.doc,.docx"
                onChange={handleFileUpload}
                className="hidden"
                id="attachments-input"
              />
              <label
                htmlFor="attachments-input"
                className={`flex items-center justify-center gap-3 p-6 border-2 border-dashed rounded-xl cursor-pointer transition-all ${
                  uploading
                    ? 'border-indigo-300 bg-indigo-50 cursor-wait'
                    : 'border-indigo-200 bg-indigo-50/50 hover:border-indigo-400 hover:bg-indigo-50'
                }`}
              >
                {uploading ? (
                  <div className="animate-spin h-5 w-5 border-2 border-indigo-500 border-t-transparent rounded-full" />
                ) : (
                  <Paperclip size={20} className="text-indigo-400" />
                )}
                <span className="text-sm text-indigo-600 font-medium">
                  {uploading ? 'جاري الرفع...' : 'اضغط لرفع ملفات (PDF, Word)'}
                </span>
                {attachments.length === 0 && (
                  <span className="text-xs text-gray-400 mr-2">(يمكن الرفع قبل الحفظ)</span>
                )}
              </label>
            </div>

            {/* Files List */}
            {attachments.length > 0 ? (
              <div className="space-y-2">
                {attachments.map((att) => (
                  <div
                    key={att.id}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="text-xl">{getFileIcon(att.file_type)}</span>
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">{att.original_name}</p>
                        <p className="text-xs text-gray-500">{formatFileSize(att.file_size)}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0 mr-2">
                      <a
                        href={att.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="تحميل"
                      >
                        <Download size={16} />
                      </a>
                      <button
                        onClick={() => handleDeleteAttachment(att.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="حذف"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <Paperclip size={36} className="mx-auto text-gray-300 mb-2" />
                <p className="text-sm text-gray-500">لا توجد مرفقات بعد</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Training Accordion */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm mt-6">
        <button
          type="button"
          onClick={() => setTrainingExpanded(!trainingExpanded)}
          className="flex items-center justify-between w-full p-7 pb-4"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-100 text-amber-600">
              <CheckCircle size={20} />
            </div>
            <h3 className="text-base font-bold text-amber-800">التدريـــــــــــــــــب</h3>
            {formData.training && (
              <span className="inline-flex items-center justify-center w-6 h-6 text-xs font-bold text-white bg-green-500 rounded-full">
                <CheckCircle size={14} />
              </span>
            )}
          </div>
          <ChevronDown size={18} className={`transition-transform duration-200 ${trainingExpanded ? 'rotate-180' : ''}`} />
        </button>

        <div
          className="overflow-hidden transition-all duration-300 ease-in-out"
          style={{ maxHeight: trainingExpanded ? '2000px' : '0' }}
        >
          <div className="px-7 pb-7">
            <div className="mb-6 border-b border-amber-100" />
            <label className="flex items-center gap-3 cursor-pointer p-4 bg-amber-50 rounded-xl hover:bg-amber-100 transition-colors">
              <input
                type="checkbox"
                checked={!!formData.training}
                onChange={(e) => {
                  const newFormData = { ...formData };
                  if (e.target.checked) {
                    newFormData.training = 'True';
                  } else {
                    delete newFormData.training;
                    newFormData.training_value = '';
                  }
                  handleFormChange(newFormData);
                }}
                className="w-5 h-5 rounded border-gray-300 text-amber-500 focus:ring-amber-500"
              />
              <span className="text-sm font-semibold text-gray-700">التدريب مطلوب</span>
            </label>
            {formData.training && (
              <div className="mt-4">
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">بيانات التدريب</label>
                <input
                  type="text"
                  value={formData.training_value || ''}
                  onChange={(e) => handleFormChange({ ...formData, training_value: e.target.value })}
                  placeholder="أدخل تفاصيل التدريب..."
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl outline-none text-sm transition-all duration-200 focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 bg-white"
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Success Modal */}
      {showSuccessModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-sm w-full mx-4 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle size={32} className="text-green-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">
              {createdContract?.isNew ? 'تم إنشاء العقد بنجاح' : 'تم تحديث العقد بنجاح'}
            </h3>
            <p className="text-gray-500 mb-6">
              رقم العقد: {createdContract?.number}
            </p>
            <div className="flex gap-3 justify-center">
              <button
                onClick={() => { setShowSuccessModal(false); navigate(`/contracts/${createdContract.id}`); }}
                className="px-5 py-2.5 text-sm font-semibold bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-colors"
              >
                فتح العقد
              </button>
              <button
                onClick={() => { setShowSuccessModal(false); navigate('/contracts'); }}
                className="px-5 py-2.5 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors"
              >
                العودة للقائمة
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
