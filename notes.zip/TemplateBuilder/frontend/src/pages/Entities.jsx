import { useState, useEffect } from 'react';
import { contractService } from '../services/contractService';
import LoadingSpinner from '../components/LoadingSpinner';
import { Landmark, Plus, Trash2, Pencil, Save, X } from 'lucide-react';
import { useToast } from '../hooks/useToast';

export default function Entities() {
  const toast = useToast();
  const [entities, setEntities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newName, setNewName] = useState('');
  const [adding, setAdding] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editName, setEditName] = useState('');

  const fetchEntities = async () => {
    setLoading(true);
    try {
      const { data } = await contractService.listEntities();
      setEntities(data.results || data);
    } catch {
      toast.error('فشل تحميل الجهات');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEntities();
  }, []);

  const handleAdd = async (e) => {
    e.preventDefault();
    const trimmed = newName.trim();
    if (!trimmed) return;
    setAdding(true);
    try {
      await contractService.createEntity({ name: trimmed });
      setNewName('');
      toast.success('تمت إضافة الجهة');
      fetchEntities();
    } catch {
      toast.error('فشل إضافة الجهة');
    } finally {
      setAdding(false);
    }
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`هل أنت متأكد من حذف "${name}"؟`)) return;
    try {
      await contractService.deleteEntity(id);
      toast.success('تم حذف الجهة');
      fetchEntities();
    } catch {
      toast.error('فشل حذف الجهة');
    }
  };

  const startEdit = (id, name) => {
    setEditingId(id);
    setEditName(name);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditName('');
  };

  const handleUpdate = async (id) => {
    const trimmed = editName.trim();
    if (!trimmed) return;
    try {
      await contractService.updateEntity(id, { name: trimmed });
      toast.success('تم تحديث الجهة');
      setEditingId(null);
      setEditName('');
      fetchEntities();
    } catch {
      toast.error('فشل تحديث الجهة');
    }
  };

  const inputClass = "w-full px-4 py-2.5 border border-gray-200 rounded-xl outline-none text-sm focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 bg-white";

  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <Landmark size={24} className="text-primary-600" />
        <h1 className="text-2xl font-bold text-gray-900">الجهات</h1>
      </div>

      <form onSubmit={handleAdd} className="bg-white rounded-xl border border-gray-200 p-4 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-3">
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">اسم الجهة</label>
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="أدخل اسم الجهة..."
              className={inputClass}
            />
          </div>
          <div className="flex items-end">
            <button
              type="submit"
              disabled={adding || !newName.trim()}
              className="flex items-center gap-2 bg-primary-600 text-white px-5 py-2.5 rounded-xl hover:bg-primary-700 transition-colors text-sm font-medium w-full justify-center disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Plus size={16} />
              {adding ? 'جاري الإضافة...' : 'إضافة'}
            </button>
          </div>
        </div>
      </form>

      {loading ? (
        <LoadingSpinner />
      ) : entities.length === 0 ? (
        <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
          <Landmark size={48} className="mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500">لا توجد جهات مسجلة</p>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="text-right px-6 py-3 text-sm font-semibold text-gray-700">#</th>
                <th className="text-right px-6 py-3 text-sm font-semibold text-gray-700">اسم الجهة</th>
                <th className="text-right px-6 py-3 text-sm font-semibold text-gray-700">الحالة</th>
                <th className="text-right px-6 py-3 text-sm font-semibold text-gray-700">تاريخ الإضافة</th>
                <th className="text-center px-6 py-3 text-sm font-semibold text-gray-700">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {entities.map((entity, index) => (
                <tr key={entity.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 text-sm text-gray-500">{index + 1}</td>
                  <td className="px-6 py-4">
                    {editingId === entity.id ? (
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="flex-1 px-3 py-1.5 border border-gray-200 rounded-lg outline-none text-sm focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500"
                          autoFocus
                        />
                        <button onClick={() => handleUpdate(entity.id)} className="p-1.5 text-green-600 hover:bg-green-50 rounded-lg" title="حفظ">
                          <Save size={16} />
                        </button>
                        <button onClick={cancelEdit} className="p-1.5 text-gray-500 hover:bg-gray-100 rounded-lg" title="إلغاء">
                          <X size={16} />
                        </button>
                      </div>
                    ) : (
                      <span className="text-sm font-medium text-gray-900">{entity.name}</span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${entity.is_active ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
                      {entity.is_active ? 'نشط' : 'غير نشط'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">
                    {new Date(entity.created_at).toLocaleDateString('ar-EG', {
                      year: 'numeric', month: 'short', day: 'numeric'
                    })}
                  </td>
                  <td className="px-6 py-4">
                    {editingId !== entity.id && (
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => startEdit(entity.id, entity.name)}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="تعديل"
                        >
                          <Pencil size={16} />
                        </button>
                        <button
                          onClick={() => handleDelete(entity.id, entity.name)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="حذف"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
