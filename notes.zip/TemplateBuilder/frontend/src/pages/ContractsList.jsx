import { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { contractService } from '../services/contractService';
import DataTable from '../components/DataTable';
import SearchBox from '../components/SearchBox';
import Pagination from '../components/Pagination';
import ConfirmationDialog from '../components/ConfirmationDialog';
import { useToast } from '../hooks/useToast';
import { downloadFile } from '../utils/helpers';
import { Eye, Pencil, Trash2, Copy, FileText, FileDown, Printer, Pen, Filter, FolderOpen, PlusCircle, ChevronDown } from 'lucide-react';
import CustomSelect from '../components/CustomSelect';

export default function ContractsList() {
  const navigate = useNavigate();
  const toast = useToast();
  const [contracts, setContracts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [sortField, setSortField] = useState('created_at');
  const [sortOrder, setSortOrder] = useState('desc');
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [contractTypes, setContractTypes] = useState([]);
  const [contractTypeFilter, setContractTypeFilter] = useState('');
  const [openDropdown, setOpenDropdown] = useState(null);
  const [childrenMap, setChildrenMap] = useState({});
  const [loadingChildren, setLoadingChildren] = useState(null);
  const dropdownRef = useRef(null);

  const fetchContracts = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page, search, ordering: `${sortOrder === 'desc' ? '-' : ''}${sortField}` };
      if (contractTypeFilter) params.contract_type = contractTypeFilter;
      const { data } = await contractService.list(params);
      setContracts(data.results || data);
      setTotal(data.count || 0);
      setTotalPages(Math.ceil((data.count || 0) / (data.page_size || 20)));
    } catch {
      toast.error('فشل تحميل العقود');
    } finally {
      setLoading(false);
    }
  }, [page, search, sortField, sortOrder, contractTypeFilter]);

  useEffect(() => { fetchContracts(); }, [fetchContracts]);

  useEffect(() => {
    contractService.listContractTypes()
      .then(({ data }) => setContractTypes(data))
      .catch(() => { });
  }, []);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setOpenDropdown(null);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleDropdown = async (contractId) => {
    if (openDropdown === contractId) {
      setOpenDropdown(null);
      return;
    }
    setOpenDropdown(contractId);
    if (!childrenMap[contractId]) {
      setLoadingChildren(contractId);
      try {
        const { data } = await contractService.getChildren(contractId);
        setChildrenMap(prev => ({ ...prev, [contractId]: data }));
      } catch {
        toast.error('فشل تحميل اللجان الإضافية');
      } finally {
        setLoadingChildren(null);
      }
    }
  };

  const handleSort = (field) => {
    if (sortField === field) {
      setSortOrder((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await contractService.delete(deleteTarget.id);
      toast.success('تم حذف العقد بنجاح');
      setDeleteTarget(null);
      fetchContracts();
    } catch {
      toast.error('فشل حذف العقد');
    }
  };

  const handleDuplicate = async (contract) => {
    try {
      const { data } = await contractService.duplicate(contract.id);
      toast.success('تم نسخ العقد');
      navigate(`/contracts/${data.id}`);
    } catch {
      toast.error('فشل نسخ العقد');
    }
  };

  const handleCreateChild = async (contract) => {
    try {
      const { data } = await contractService.duplicate(contract.id, contract.id);
      toast.success('تم إنشاء اللجنة الإضافية');
      navigate(`/contracts/${data.id}`);
    } catch {
      toast.error('فشل إنشاء اللجنة الإضافية');
    }
  };

  const handleDownloadWord = async (contract) => {
    try {
      const response = await contractService.downloadWord(contract.id);
      downloadFile(response.data, `contract_${contract.contract_number}.docx`);
      toast.success('تم تحميل ملف Word');
    } catch { toast.error('فشل تحميل الملف'); }
  };

  const handleDownloadPdf = async (contract) => {
    try {
      const response = await contractService.downloadPdf(contract.id);
      downloadFile(response.data, `contract_${contract.contract_number}.pdf`);
      toast.success('تم تحميل ملف PDF');
    } catch { toast.error('فشل تحميل الملف'); }
  };

  const columns = [
    { key: 'contract_number', label: 'رقم العقد', sortable: true },
    {
      key: 'contract_type',
      label: 'نوع العقد',
      render: (row) => row.contract_type?.name || '—',
    },
    { key: 'created_at', label: 'تاريخ الإنشاء', sortable: true, render: (row) => new Date(row.created_at).toLocaleDateString('ar-SA') },
  ];

  return (
    <div>
      <div className="sticky top-0 z-40 -mx-6 -mt-6 px-6 pt-6 pb-4 mb-6 bg-white/80 backdrop-blur-md border-b border-gray-200 no-print">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-bold text-gray-900">العقود</h1>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="p-4 border-b border-gray-100 space-y-3">
          <SearchBox value={search} onChange={(v) => { setSearch(v); setPage(1); }} placeholder="بحث عن عقد..." />
          <div className="flex items-center gap-3 flex-wrap">
            <Filter size={16} className="text-gray-400" />
            <CustomSelect
              size="sm"
              value={contractTypeFilter}
              options={[
                { id: '', label: 'نوع العقد : الكل' },
                ...contractTypes.map(t => ({ id: String(t.id), label: t.name })),
              ]}
              onChange={(v) => { setContractTypeFilter(v); setPage(1); }}
            />
          </div>
        </div>
        <DataTable
          columns={columns}
          data={contracts}
          onSort={handleSort}
          sortField={sortField}
          sortOrder={sortOrder}
          loading={loading}
          actions={(row) => (
            <div className="flex gap-1 flex-wrap">
              <button onClick={() => navigate(`/contracts/${row.id}`)} className="flex items-center gap-1.5 px-2 py-1.5 text-blue-600 hover:bg-blue-50 rounded whitespace-nowrap">
                <Eye size={15} />
                <span>عرض</span>
              </button>
              <button onClick={() => navigate(`/contracts/${row.id}?quickEdit=true`)} className="flex items-center gap-1.5 px-2 py-1.5 text-indigo-600 hover:bg-indigo-50 rounded whitespace-nowrap">
                <Pen size={15} />
                <span>تعديل سريع</span>
              </button>
              <button onClick={() => navigate(`/contracts/${row.id}/edit`)} className="flex items-center gap-1.5 px-2 py-1.5 text-amber-600 hover:bg-amber-50 rounded whitespace-nowrap">
                <Pencil size={15} />
                <span>تعديل</span>
              </button>
              <button onClick={() => handleDuplicate(row)} className="flex items-center gap-1.5 px-2 py-1.5 text-purple-600 hover:bg-purple-50 rounded whitespace-nowrap">
                <Copy size={15} />
                <span>نسخ</span>
              </button>
              {!row.parent_committee && (
                <div className="relative" ref={openDropdown === row.id ? dropdownRef : null}>
                  <button
                    onClick={() => toggleDropdown(row.id)}
                    className="flex items-center gap-1.5 px-2 py-1.5 text-cyan-600 hover:bg-cyan-50 rounded whitespace-nowrap"
                  >
                    <PlusCircle size={15} />
                    <span>لجنة إضافية</span>
                    {row.children_count > 0 && (
                      <span className="bg-cyan-100 text-cyan-700 text-xs font-bold px-1.5 py-0.5 rounded-full">{row.children_count}</span>
                    )}
                    <ChevronDown size={13} />
                  </button>
                  {openDropdown === row.id && (
                    <div className="absolute left-0 top-full mt-1 bg-white border border-gray-200 rounded-lg shadow-xl z-50 min-w-[240px] max-h-[300px] overflow-auto">
                      {loadingChildren === row.id ? (
                        <div className="px-4 py-3 text-sm text-gray-400 text-center">جاري التحميل...</div>
                      ) : (childrenMap[row.id]?.length > 0) ? (
                        <>
                          {childrenMap[row.id].map(child => (
                            <button
                              key={child.id}
                              onClick={() => { setOpenDropdown(null); navigate(`/contracts/${child.id}`); }}
                              className="w-full text-right px-4 py-2.5 hover:bg-cyan-50 flex items-center gap-2 text-sm border-b border-gray-50 last:border-0"
                            >
                              <FileText size={14} className="text-cyan-500 flex-shrink-0" />
                              <span className="truncate">{child.contract_number}</span>
                            </button>
                          ))}
                          <button
                            onClick={async () => {
                              try {
                                const { data } = await contractService.duplicate(row.id, row.id);
                                toast.success('تم إنشاء اللجنة الإضافية');
                                setOpenDropdown(null);
                                setChildrenMap(prev => ({ ...prev, [row.id]: undefined }));
                                navigate(`/contracts/${data.id}`);
                              } catch {
                                toast.error('فشل إنشاء اللجنة الإضافية');
                              }
                            }}
                            className="w-full text-right px-4 py-2.5 hover:bg-cyan-50 flex items-center gap-2 text-sm text-cyan-600 font-medium"
                          >
                            <PlusCircle size={14} className="flex-shrink-0" />
                            <span>إضافة لجنة جديدة</span>
                          </button>
                        </>
                      ) : (
                        <button
                          onClick={async () => {
                            try {
                              const { data } = await contractService.duplicate(row.id, row.id);
                              toast.success('تم إنشاء اللجنة الإضافية');
                              setOpenDropdown(null);
                              setChildrenMap(prev => ({ ...prev, [row.id]: undefined }));
                              navigate(`/contracts/${data.id}`);
                            } catch {
                              toast.error('فشل إنشاء اللجنة الإضافية');
                            }
                          }}
                          className="w-full text-right px-4 py-2.5 hover:bg-cyan-50 flex items-center gap-2 text-sm text-cyan-600 font-medium"
                        >
                          <PlusCircle size={14} className="flex-shrink-0" />
                          <span>إضافة لجنة جديدة</span>
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}
              <button
                onClick={async () => {
                  try {
                    await contractService.openStorageFolder(row.id);
                    toast.success('تم فتح المجلد');
                  } catch (err) {
                    if (err.response?.status === 404) {
                      toast.error('لم يتم إنشاء الملف بعد');
                    } else {
                      toast.error('فشل فتح المجلد');
                    }
                  }
                }}
                className="flex items-center gap-1.5 px-2 py-1.5 text-teal-600 hover:bg-teal-50 rounded whitespace-nowrap"
              >
                <FolderOpen size={15} />
                <span>فتح المجلد</span>
              </button>
              <button onClick={() => handleDownloadWord(row)} className="flex items-center gap-1.5 px-2 py-1.5 text-green-600 hover:bg-green-50 rounded whitespace-nowrap">
                <FileText size={15} />
                <span>Word</span>
              </button>
              {/* <button onClick={() => handleDownloadPdf(row)} className="flex items-center gap-1.5 px-2 py-1.5 text-red-600 hover:bg-red-50 rounded whitespace-nowrap">
                <FileDown size={15} />
                <span>PDF</span>
              </button>
              <button onClick={() => window.open(`/contracts/${row.id}?print=true`, '_blank')} className="flex items-center gap-1.5 px-2 py-1.5 text-gray-600 hover:bg-gray-100 rounded whitespace-nowrap">
                <Printer size={15} />
                <span>طباعة</span>
              </button> */}
              <button onClick={() => setDeleteTarget(row)} className="flex items-center gap-1.5 px-2 py-1.5 text-red-600 hover:bg-red-50 rounded whitespace-nowrap">
                <Trash2 size={15} />
                <span>حذف</span>
              </button>
            </div>
          )}
        />

        <div className="px-4 py-3 border-t border-gray-100">
          <Pagination currentPage={page} totalPages={totalPages} total={total} onPageChange={setPage} />
        </div>
      </div>

      <ConfirmationDialog
        open={!!deleteTarget}
        title="حذف العقد"
        message={`هل أنت متأكد من حذف العقد "${deleteTarget?.contract_number}"؟`}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
        confirmText="حذف"
        cancelText="إلغاء"
        variant="danger"
      />
    </div>
  );
}
